import multiprocessing
import os
import time
from multiprocessing import Process, Manager
from helper import get_ip_add_and_url, write_markdown_table


class Analyzer:
    def __init__(self, f, p_start, p_end, id):
        self.f = f
        self.p_start = p_start
        self.p_end = p_end
        self.id = id

    def run(self,
            shared_page_report_dict,
            shared_ip_report_dict,
            shared_full_report_dict,
            line_counter
            ):
        with open(self.f, 'rb') as fp:
            print(f'进程{self.id}开始执行了...')
            # 避免读到截断的字符，从下一行开始处理
            if self.p_start:
                fp.seek(self.p_start - 1)
                while b'\n' not in fp.read(1):
                    pass

            while True:
                line = fp.readline()
                if not line:
                    break
                # 获取ip地址和文章url
                res = get_ip_add_and_url(line, [b'html', b'docx', b'zip'])
                if not res:
                    continue
                ip_add, file_url = res
                # print(f'{self.id}-{ip_add}-{file_url}')
                # 更新reporters
                self.update_page_reporter(shared_page_report_dict, ip_add, file_url)
                self.update_ip_reporter(shared_ip_report_dict, ip_add, file_url)
                self.update_full_reporter(shared_full_report_dict, ip_add, file_url)
                line_counter.value += 1
                # print(f'{self.id}-finish line: {line_counter}')

                pos = fp.tell()
                if pos >= self.p_end:
                    print(f'进程{self.id}执行完毕.')
                    return

    @staticmethod
    def update_page_reporter(url_map: dict, ip_add, file_url: str):
        # 更新文章报表
        # url_map = {
        #     file_url: {
        #         'title': str,
        #         'visits_count': int,
        #         'ips': set
        #     }
        # }
        if file_url not in url_map.keys():
            # 新增
            url_map[file_url] = {
                'visits_count': 1,
                'ips': {ip_add}
            }
        else:
            # 更新
            url_map[file_url]['visits_count'] += 1
            url_map[file_url]['ips'].add(ip_add)

    @staticmethod
    def update_ip_reporter(ip_map: dict, ip_add, file_url: str):
        # 更新ip报表数据
        # 格式：
        # ip_map = {
        #     ip_add: {
        #         'visits_count': int,
        #         'visited_pages': set
        #     }
        # }
        if ip_add not in ip_map.keys():
            ip_map[ip_add] = {
                'visits_count': 1,
                'visited_pages': {file_url}
            }
        else:
            ip_map[ip_add]['visits_count'] += 1
            ip_map[ip_add]['visited_pages'].add(file_url)

    @ staticmethod
    def update_full_reporter(url_ip_map: dict, ip_add, file_url: str):
        # 更新完整报表
        # url_ip_map = {
        #     url: {
        #         ip: visits_count
        #     }
        # }
        if file_url not in url_ip_map.keys():
            # 新增
            url_ip_map[file_url] = {ip_add: 1}
        # 更新
        else:
            # 如果ip键不存在
            if ip_add not in url_ip_map[file_url].keys():
                url_ip_map[file_url][ip_add] = 1
            else:
                url_ip_map[file_url][ip_add] += 1

    @staticmethod
    def gen_page_report(url_map: dict, report_file_path: str) -> None:
        file = write_markdown_table(
            report_file_path,
            ['URL', '文章标题', '访问人次', '访问IP数'],
            'l'
        )
        for k in url_map.keys():
            v = url_map[k]
            file.write(
                '| {} | {} | {} | {} |\n'.format(
                    k,
                    # TODO 获取页面标题
                    # get_page_title('200.200.1.35/{}'.format(k)),
                    'NOT FOUND',
                    v['visits_count'],
                    len(v['ips'])
                )
            )
        file.close()

    @staticmethod
    def gen_ip_report(ip_map: dict, report_file_path: str) -> None:
        file = write_markdown_table(
            report_file_path,
            ['IP', '访问次数', '访问文章数'],
            'l'
        )
        for k in ip_map.keys():
            v = ip_map[k]
            file.write(
                '| {} | {} | {} |\n'.format(
                    k,
                    v['visits_count'],
                    len(v['visited_pages'])
                )
            )
        file.close()

    @staticmethod
    def gen_full_report(url_ip_map: dict, report_file_path: str) -> None:
        file = write_markdown_table(
            report_file_path,
            ['IP', 'URL', '访问次数'],
            'l'
        )
        for url in url_ip_map.keys():
            for ip in url_ip_map[url].keys():
                file.write(
                    '| {} | {} | {} |\n'.format(
                        ip,
                        url,
                        url_ip_map[url][ip]
                    )
                )
        file.close()


class Runner:
    def __init__(
            self,
            in_file,
            workers,
            file_filter,
            page_report_path,
            ip_report_path,
            full_report_path
    ):
        if not os.path.isfile(in_file):
            raise FileNotFoundError('文件不存在。')
        self.f = in_file
        self.f_size = os.path.getsize(in_file)
        self.file_filter = file_filter

        self.workers = workers
        self.analyzers = []
        self.ps = []

        self.page_report_path = page_report_path
        self.ip_report_path = ip_report_path
        self.full_report_path = full_report_path

    def run(self):
        # 用共享内存保存每个进程的处理结果
        line_counter = multiprocessing.Value('d', 0)
        with Manager() as m:
            shared_page_report_dict = Manager().dict()
            shared_ip_report_dict = Manager().dict()
            shared_full_report_dict = Manager().dict()

        for i in range(self.workers):
            # 将大文件f分段后分发给不同的analyzer进程
            p_start = self.f_size * i // self.workers
            p_end = self.f_size * (i + 1) // self.workers
            self.analyzers.append(Analyzer(
                self.f, p_start, p_end, i
            ))
            self.ps.append(
                Process(
                    target=self.analyzers[i].run,
                    args=(
                        shared_page_report_dict,
                        shared_ip_report_dict,
                        shared_full_report_dict,
                        line_counter
                    )
                )
            )
        # 开启全部进程
        [p.start() for p in self.ps]
        # 等待进程结束
        [p.join() for p in self.ps]

        print(shared_full_report_dict)


# if __name__ == '__main__':
#     workers = 128
#     file_path = './data/test_data.txt'
#
#     t2 = time.time()
#     runner = Runner(file_path, workers, "", "", "")
#     runner.run()
#     print(f'{workers}进程, 耗时: {time.time() - t2}')


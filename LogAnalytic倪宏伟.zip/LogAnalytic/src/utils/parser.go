package utils

import (
	"regexp"
	"strings"
)

var urlReg = regexp.MustCompile(`(\S)*(htm|docx|pdf|doc|mpg|zip)`)
var ipReg = regexp.MustCompile(`((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[09][0-9]|[1-9][0-9]|[0-9])`)

func GetIPBySplit(line string) string {
	var ipaddr string
	spaceIndex := strings.Index(line, " ")
	if spaceIndex == -1 {
		ipaddr = ""
	} else {
		ipaddr = line[:spaceIndex]
	}
	return ipaddr
}

func GetUrlBySplit(line string) string {
	url := strings.Split(line, "\"")[1]
	url = strings.Split(url, " ")[1]
	return url
}

func GetIPByRegular(line string) string {
	return ipReg.FindString(line)
}

func GetURLByRegular(line string) string {
	return urlReg.FindString(line)
}

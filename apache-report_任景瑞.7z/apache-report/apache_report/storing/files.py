# coding=utf-8
from apache_report import exception
from apache_report.storing.formatting import markdown_format
from apache_report.common.utils import set_logger


logger = set_logger()


class FileWriter(object):

    @classmethod
    def write_file_to_txt(cls, file_name, data, columns):
        table = markdown_format(data, columns)
        try:
            with open(file_name, 'w') as wf:
                wf.writelines(table)
        except IOError:
            logger.exception("文件错误")
            raise exception.FileStreamException()

    @classmethod
    def write_file_to_txt_with_head(
            cls, file_name, data, cols_name, head_name=None, rows_name=None):
        table = markdown_format(
            data, cols_name, head_name, rows_name)
        try:
            with open(file_name, 'w') as wf:
                wf.writelines(table)
        except IOError:
            logger.exception("文件错误")
            raise exception.FileStreamException()

# TODO 多线程写多个文件

import random
import uuid


def gen_fake_ips(start_add="1.1.1.1", num=1):
    res = []
    starts = start_add.split('.')
    A = int(starts[0])
    B = int(starts[1])
    C = int(starts[2])
    D = int(starts[3])
    for A in range(A, 256):
        for B in range(B, 256):
            for C in range(256):
                for D in range(D, 256):
                    if num > 0:
                        res.append("%d.%d.%d.%d" % (A, B, C, D))
                        num -= 1
                    else:
                        break
                D = 0
            C = 0
        B = 0

    return res


def gen_fake_apache_log(ip_start_add="132.106.80.16", ip_num=1, log_num=10, output_file_path="../data/fake_apache_log.txt"):
    file = open(output_file_path, 'w')
    fake_ips = gen_fake_ips(ip_start_add, ip_num)
    fake_file_urls = [
        '/coding',
        '/material',
        '/pictures',
        '/videos',
        '/designing',
        '/tools',
        '/images',
        '/gitbook',
        '/plugins'
    ]
    fake_file_postfix = [
        '.js',
        '.css',
        '.htm',
        '.html',
        '.pdf',
        '.doc',
        '.docx',
        '.pdf',
        '.zip',
        '.ico'
    ]
    count = 1
    while True:
        # 拼接假文章url
        fake_url = '{} - - [16/Feb/2019:11:27:20 +0800] "GET {}/{}{} HTTP/1.1" 200 6447'.format(
            random.choice(fake_ips),
            random.choice(fake_file_urls),
            # uuid.uuid4().hex,
            random.choice(['sun', 'dog', 'rain', 'cute', 'hot', 'python', 'golang', 'shell']),
            random.choice(fake_file_postfix)
            )
        if count < log_num:
            file.write(fake_url + '\n')
            count += 1
        elif count == log_num:  # 解决最后多一行回车问题
            file.write(fake_url)
            count += 1
        else:
            break

    file.close()


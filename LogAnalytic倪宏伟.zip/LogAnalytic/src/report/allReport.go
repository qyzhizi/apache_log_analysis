package report

import (
	"fmt"
	"io"
	"nhw-log/common"
	"strings"
)

type AllReport struct {
	ReportConetent map[string]int
	Name           string
	title          []string
}

func (all *AllReport) Finish() {
}

func (all *AllReport) SetTitle(title []string) {
	all.title = title
}

func (all *AllReport) GetTitle() []string {
	return all.title
}

func (all *AllReport) Merge(report Report) {
	allmap := report.Values().(map[string]int)
	for key, val := range allmap {
		all.ReportConetent[key] += val
	}

}

func (all *AllReport) Values() interface{} {
	return all.ReportConetent
}

func (all *AllReport) Names() string {
	return all.Name
}

func (all *AllReport) Init() {
	all.ReportConetent = make(map[string]int)
	all.Name = "all"
}

func (all *AllReport) Set(url string, ip string) {
	key := url + " " + ip
	all.ReportConetent[key]++
}

func (all *AllReport) Export(writer io.Writer, exportType string) {
	if exportType == common.MD {
		GenerateMDTitle(writer, all.title)
		for key, reqCount := range all.ReportConetent {
			fields := strings.Fields(key)
			fmt.Fprintf(writer, "|%s|%s|%d|\n", fields[1], fields[0], reqCount)
		}
	} else if exportType == common.HTML {
		GenerateHTMLTitle(writer,all.title)
		for key, reqCount := range all.ReportConetent {
			fields := strings.Fields(key)
			fmt.Fprintf(writer, "<tr><td>%s</td><td>%s</td><td>%d</td></tr>\n",
				fields[1], fields[0], reqCount)
		}
	}
}

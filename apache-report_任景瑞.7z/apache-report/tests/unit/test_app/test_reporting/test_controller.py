import unittest

from apache_report.app.reporting.controller import ArticleManager
from apache_report.app.reporting.controller import IPReportManager
from apache_report.app.reporting.controller import CompleteReportManager
from apache_report.app.parse_log import core_parse_opt


with open('/apache_log.txt') as f:
    test_data = f.readlines()
res = []
for d in test_data:
    res.append(core_parse_opt(d))


class TestArticleManager(unittest.TestCase):
    def setUp(self):
        super(TestArticleManager, self).setUp()

    def test_generate_article_table(self):
        manager = ArticleManager(res)
        manager.generate_table()
        access_list = []
        access_ip = []
        for i in manager.tables:
            access_list.append(i[2])
            access_ip.append(i[3])
        self.assertEqual(access_list,
                         [3, 3, 5, 5, 3, 3, 4, 3, 4, 3, 3, 5, 5, 3, 3, 3, 3,
                          4, 3, 3, 6, 3, 3, 3, 3, 3, 5, 3, 3, 3, 5, 4, 3, 3,
                          4, 5, 3, 3, 3])
        self.assertEqual(access_ip,
                         [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                          1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                          1, 1, 1, 1, 1, 1])

    def test_generate_ip_table(self):
        manager = IPReportManager(res)
        manager.generate_table()
        access_freq = []
        access_article = []
        for i in manager.tables:
            access_freq.append(i[1])
            access_article.append(i[2])
        self.assertEqual(access_freq,
                         [13, 124, 5])
        self.assertEqual(access_article,
                         [3, 36, 1])

    def test_generate_complete_table(self):
        manager = CompleteReportManager(res)
        manager.generate_table()
        access_freq = []
        for i in manager.tables:
            access_freq.append(i[2])
        self.assertEqual(access_freq,
                         [3, 3, 5, 5, 3, 3, 4, 3, 4, 3, 3, 5, 5, 3, 3, 3, 3,
                          4, 3, 3, 6, 3, 3, 3, 3, 3, 5, 3, 3, 3, 5, 4, 3, 3,
                          3, 4, 5, 3, 3, 3, 3, 3, 5, 5, 3, 3, 4, 3, 4, 3, 3,
                          5, 5, 3, 3, 3, 3, 4, 3, 3, 6, 3, 3, 3, 3, 3, 5, 3,
                          3, 3, 5, 4, 3, 3, 3, 4, 5, 3, 3, 3, 3, 3, 5, 5, 3,
                          3, 4, 3, 4, 3, 3, 5, 5, 3, 3, 3, 3, 4, 3, 3, 6, 3,
                          3, 3, 3, 3, 5, 3, 3, 3, 5, 4, 3, 3, 3, 4, 5, 3, 3,
                          3])




# -*- coding: utf-8 -*-
import sys
import unittest
import mock
sys.path.append('../../../')
from apache_log_analysis.common.config import RE_LOG_LINE_PATTERN
from apache_log_analysis.common.config import LOG_FILE
from apache_log_analysis.app.log_analysis import LogAnalysis
from apache_log_analysis.common.data_models import LogNames
from apache_log_analysis.common.data_models import IpReportData


# from common.config import ARTICLE_TABLE_PATH
# from common.config import IP_TABLE_PATH
# from common.config import WHOLE_TABLE_PATH


class TestApacheLogAnalysis(unittest.TestCase):
    u"""apache日志分析测试类."""

    def setUp(self):
        self.mock_apache_list = ['200.200.76.130 - - [16/Feb/2019:11:27:20 '
                                 '+0800] "GET /coding/miniprj/material.html '
                                 'HTTP/1.1" 200 38093',
                                 '200.200.76.135 - - [16/Feb/2019:11:27:20 '
                                 '+0800] "GET /coding/miniprj/material.html'
                                 ' HTTP/1.1" 200 38093',
                                 '200.200.76.131 - - [16/Feb/2019:11:27:20 '
                                 '+0800] "GET /coding/miniprj/material2.html'
                                 ' HTTP/1.1" 200 38093',
                                 '200.200.76.132 - - [16/Feb/2019:11:27:20 '
                                 '+0800] "GET /coding/miniprj/material3.html'
                                 ' HTTP/1.1" 200 38093',
                                 '200.200.76.133 - - [16/Feb/2019:11:27:20 +0'
                                 '800] "GET /coding/miniprj/material4.html'
                                 ' HTTP/1.1" 200 38093',
                                 '200.200.76.133 - - [16/Feb/2019:11:27:20 +0'
                                 '800] "GET /coding/miniprj/material4.html'
                                 ' HTTP/1.1" 200 38093'
                                 ]
        # log_preprocess_result
        self.mock_log_preprocess_result = [
            ('200.200.76.130', 'GET', '/coding/miniprj/material.html', 'html'),
            ('200.200.76.135', 'GET', '/coding/miniprj/material.html', 'html'),
            (
            '200.200.76.131', 'GET', '/coding/miniprj/material2.html', 'html'),
            (
            '200.200.76.132', 'GET', '/coding/miniprj/material3.html', 'html'),
            ('200.200.76.133', 'GET', '/coding/miniprj/material4.html', 'html'),
            ('200.200.76.133', 'GET', '/coding/miniprj/material4.html', 'html')
        ]

        self.mock_article_report_url_nums = {
            '/coding/miniprj/material.html': 2,
            '/coding/miniprj/material2.html': 1,
            '/coding/miniprj/material3.html': 1,
            '/coding/miniprj/material4.html': 2
        }

        self.mock_article_report_url_ip = {
            '/coding/miniprj/material.html': {'200.200.76.130',
                                              '200.200.76.135'},
            '/coding/miniprj/material2.html': {'200.200.76.131'},
            '/coding/miniprj/material3.html': {'200.200.76.132'},
            '/coding/miniprj/material4.html': {'200.200.76.133'}
        }

        self.mock_article_report_url_title = {
            '/coding/miniprj/material2.html': 'This is a default title'
        }

        self.mock_ip_report_dict = {
            '200.200.76.130': {'ip_nums': 1, 'ip_articles': 1}
        }

        self.mock_whole_report_dict = {
            '200.200.76.130': {'/coding/miniprj/material.html': 1}
        }

    def tearDown(self):
        pass

    # @mock.patch("%s.DataHolder.save" % COMMON_MOCK_PATH)
    # @mock.patch("%s.DataHolder.load" % COMMON_MOCK_PATH)
    def test_get_article_report_data(self):
        log_analysis = LogAnalysis(LOG_FILE, RE_LOG_LINE_PATTERN)
        article_data = log_analysis._get_article_report_data(
            self.mock_log_preprocess_result)
        url = LogNames.URL
        ip = LogNames.IP

        # 测试 文章报表数据 article_data.url_ip
        url_0 = self.mock_log_preprocess_result[0][url]
        ip_0 = self.mock_log_preprocess_result[0][ip]
        self.assertIn(ip_0, article_data.url_ip[url_0])
        # 测试 文章报表数据 article_data.url_num
        self.assertEqual(article_data.url_num['/coding/miniprj/material.html'],
                         2)
        # 测试 文章报表数据 article_data.url_ip
        self.assertEqual(article_data.url_ip['/coding/miniprj/material3.html'],
                         {'200.200.76.132'})
        # 测试 文章报表数据 article_data.url_title
        self.assertNotEqual(
            article_data.url_title['/coding/miniprj/material2.html'],
            'This is a default title 2'
        )

    def test_get_ip_report_data(self):
        log_analysis = LogAnalysis(LOG_FILE, RE_LOG_LINE_PATTERN)
        ip_data = log_analysis._get_ip_report_data(
            self.mock_log_preprocess_result)
        ip_nums = ip_data.IP_NUMS
        ip_articles = ip_data.IP_ARTICLES

        # 测试 ip报表数据 ip_data.ip_report_dict
        self.assertEqual(ip_data.ip_report_dict['200.200.76.130'],
                         {'ip_nums': 1, 'ip_articles': 1})

    def test_get_whole_report_data(self):
        log_analysis = LogAnalysis(LOG_FILE, RE_LOG_LINE_PATTERN)
        whole_data = log_analysis._get_whole_report_data(
            self.mock_log_preprocess_result)

        # 测试 完整报表数据 ip_data.ip_report_dict
        self.assertEqual(whole_data.whole_report_dict['200.200.76.130'],
                         {'/coding/miniprj/material.html': 1})


if __name__ == '__main__':
    unittest.main()

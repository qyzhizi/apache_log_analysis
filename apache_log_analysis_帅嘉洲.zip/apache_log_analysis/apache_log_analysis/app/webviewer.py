from urllib import request, error
from bs4 import BeautifulSoup


class TitleGetter(object):
    URL_PREFIX = "http://200.200.1.35"
    CAN_NOT_REACH = "[无法访问]"
    NO_TITLE = "[无法获取标题]"

    def get_article_title(self, url):
        """根据url获取文章标题

        传来的数据依据去重，所以不需要缓存
        :param url: 路径，这个路径从日志来，不包括域名或IP
        :return: 文章标题
        """
        return self.CAN_NOT_REACH
        # try:
        #     # 拼接成完整路径并请求
        #     res = request.urlopen(self.URL_PREFIX+url, timeout=100)
        #     soup = BeautifulSoup(res, 'lxml')
        #     title = soup.title.string
        #     return title
        # except error.URLError:
        #     return self.CAN_NOT_REACH
        # # soup没有title
        # except AttributeError:
        #     return self.NO_TITLE

# -*- coding: utf-8 -*-

import logging
import logging.handlers

from apache_analyse.common.constant import DEFAULT_PUBLIC_LOG_FILE_NAME, \
    DEFAULT_PUBLIC_LOG_FORMATTER, DEFAULT_ERROR_LOG_FILE_NAME, \
    DEFAULT_ERROR_LOG_FORMATTER


def get_log():
    """
    返回自定义日志器
    public_log 记录所有日志信息， 格式：日期-级别-信息
    error_log 记录error级别以上的日志信息， 格式：日期-级别-文件[:行号]-信息
    :return: logging
    """
    logger = logging.getLogger("ApacheAnalyseLog")
    logger.setLevel(logging.DEBUG)

    public_handler = logging.FileHandler(DEFAULT_PUBLIC_LOG_FILE_NAME)
    public_handler.setFormatter(
        logging.Formatter(DEFAULT_PUBLIC_LOG_FORMATTER))

    error_handler = logging.FileHandler(DEFAULT_ERROR_LOG_FILE_NAME)
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(logging.Formatter(DEFAULT_ERROR_LOG_FORMATTER))

    logger.addHandler(public_handler)
    logger.addHandler(error_handler)
    return logger

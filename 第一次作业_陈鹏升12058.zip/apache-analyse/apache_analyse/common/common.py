# -*- coding: utf-8 -*-
from multiprocessing import Pool
from time import time

from apache_analyse.common.log import get_log
from apache_analyse.common.constant import DEFAULT_REMOVE_URL_TYPE, \
    MAX_DIRECT_FILTER_SIZE, DEFAULT_WORKERS

_logger = get_log()


def filter_log(log_list):
    """
    日志记录超过一定值并发方式进行处理
    :param log_list:
    :return:
    """
    _logger.debug("start filter log")

    begin_time = time()
    log_size = len(log_list)
    if log_size > MAX_DIRECT_FILTER_SIZE:
        pool = Pool(DEFAULT_WORKERS)
        jobs = []
        for i in range(log_size // MAX_DIRECT_FILTER_SIZE):
            start_index = i * MAX_DIRECT_FILTER_SIZE
            end_index = (i + 1) * MAX_DIRECT_FILTER_SIZE
            if end_index > log_size:
                end_index = log_size

            jobs.append(pool.apply_async(_filter_log,
                                         (log_list, start_index, end_index,)))
        res = [format_dict for job in jobs for format_dict in job.get()]

        pool.close()
        pool.join()
        print("清洗时间：%s" % str(time() - begin_time))
        return res
    else:
        res = _filter_log(log_list, 0, log_size)
        print("清洗时间：%s" % str(time() - begin_time))
        return res


def _filter_log(log_list, start_index, end_index):
    """
    清洗日志
    返回格式{ip, method, url, type, title, status_code}
    :param log_list:
    :param start_index:
    :param end_index:
    :return:
    """
    format_list = []
    for i in range(start_index, end_index):
        log_split = log_list[i].split(' ')
        if len(log_split) < 10:
            continue
        if log_split[6].endswith(DEFAULT_REMOVE_URL_TYPE):
            continue
        format_list.append({'ip': log_split[0],
                            'method': log_split[5],
                            'url': log_split[6],
                            'type': log_split[6].split('.')[-1],
                            'title': get_default_title(log_split[6]),
                            'status_code': log_split[8]})
    return format_list


def get_default_title(url):
    if isinstance(url, str):
        return url.split('/')[-1].split('.')[0]

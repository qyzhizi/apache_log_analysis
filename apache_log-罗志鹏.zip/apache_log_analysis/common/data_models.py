# -*- coding: utf-8 -*-

class LogNames(object):

    # IP = 'ip'
    # TIME = 'time'
    # METHOD = 'method'
    # URL = 'url'
    # FILE_TYPE = 'file_type'
    # PROTOCOL = 'protocol'
    # CODE = 'code'
    # BYTES = 'bytes'

    IP = 0
    METHOD = 1
    URL = 2
    FILE_TYPE = 3

    names = [IP, METHOD, URL, FILE_TYPE]


class FileType(object):
    type1 = {'html', 'htm', 'pdf', 'docx'}
    type2 = {'js', 'css'}
    type3 = {'mpg'}


class ArticleReportDate(object):
    def __init__(self):
        # {url_1: nums1, url_2: nums2, ...}
        self.url_num = {}
        # {url_1: {ip1, ip2,...}, rul_2: {ip1, ip2,...}}
        self.url_ip = {}
        # {url_1: title_1, url_2: title_2, ...}
        self.url_title = {}


class IpReportData(object):
    def __init__(self):
        """
        {ip1: {'ip_nums': 0, 'ip_articles': 0}, ip2 :{'ip_nums': 0, \
         'ip_articles': 0}, ...}
        """

        self.IP_NUMS = 'ip_nums'
        self.IP_ARTICLES = 'ip_articles'
        self.ip_report_dict = {}


class WholeReportDate(object):
    def __init__(self):
        """
        {ip1：{url1:nums1, url2:nums2, url3:nums3,...},\
        ip2：{url1:nums1, url2:nums2, url3:nums3,...}, ... }

        """
        self.whole_report_dict = {}


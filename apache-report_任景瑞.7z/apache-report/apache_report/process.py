import multiprocessing as mp
import time


def pickle_op(_class, *args):
    return _class.proc_func(*args)


class Optional(object):
    def __init__(self):
        self.manager = mp.Manager()
        self.mp_list = self.manager.list()
        self.mp_dict = self.manager.dict()
        self.length = 32

    def proc_func(self, i, j):
        self.mp_list.append(i)
        self.mp_dict[i] = j
        time.sleep(0.1)

    def flow(self):
        pool = mp.Pool(6)
        for i in range(self.length):
            pool.apply_async(pickle_op, args=(self, i, i**2))
        pool.close()
        pool.join()


# -*- coding: utf-8 -*-

from multiprocessing import Pool

from apache_analyse.common.log import get_log
from apache_analyse.common.constant import DEFAULT_ARTICLE_URL_TYPE, \
    URL_RESPONSE, URL_ATTR_RESPONSE, MAX_DIRECT_TABLE_SIZE, DEFAULT_WORKERS

_logger = get_log()


class UrlHolder:

    @staticmethod
    def get_response(url, method, params):
        """
        返回url请求内容
        :param url: 请求路径
        :param method: 请求方法
        :param params: 请求参数
        :return:
        """
        return URL_RESPONSE.get(method)


class Resource:

    @staticmethod
    def _get_response_attr(response, method, selector):
        """
        获取需要解析的内容
        :param response: url内容
        :param method: 请求方法
        :param selector: 要解析内容
        :return:
        """
        return URL_ATTR_RESPONSE.get(method)

    def _get_all_article_title(self, **kwargs):
        """
        获取文章的标题
        :param kwargs:
        :return:
        """
        response = UrlHolder.get_response(kwargs['url'], kwargs['method'],
                                          kwargs['params'])
        title = self._get_response_attr(response, kwargs['method'],
                                        kwargs['selector'])
        kwargs['article_table']['title'] = title

    def _get_table_by_pool(self, func, filter_log_list):
        log_size = len(filter_log_list)
        if log_size > MAX_DIRECT_TABLE_SIZE:
            pool = Pool(DEFAULT_WORKERS)
            jobs = []
            for i in range(log_size // MAX_DIRECT_TABLE_SIZE):
                start_index = i * MAX_DIRECT_TABLE_SIZE
                end_index = (i + 1) * MAX_DIRECT_TABLE_SIZE
                if end_index > log_size:
                    end_index = log_size

                jobs.append(pool.apply_async(func,
                                             (filter_log_list, start_index,
                                              end_index,)))
            res = {}
            for job in jobs:
                res.update(job.get())
            pool.close()
            pool.join()
            return res
        else:
            res = func(filter_log_list, 0, log_size)
            return res

    def _get_article_report(self, filter_log_list, start_index, end_index):
        """
        生成文章报表的内容
        :param filter_log_list:
        :return:
        """
        article_table_dict = {}
        for index in range(start_index, end_index):
            if not filter_log_list[index]:
                continue
            if not article_table_dict.get(filter_log_list[index]['url']):
                article_dict = {'url': filter_log_list[index]['url'],
                                'title': filter_log_list[index]['title'],
                                'url_type': filter_log_list[index]['type'],
                                'visits': 0,
                                'ip_counts': 0,
                                'ip_dist': {}}
                article_table_dict[filter_log_list[index][
                    'url']] = article_dict
            # 访问数+1
            article_table_dict[filter_log_list[index]['url']]['visits'] += 1
            # 添加到访问过的ip
            if not article_table_dict[filter_log_list[index]['url']][
                    'ip_dist'].get(filter_log_list[index]['ip']):
                article_table_dict[filter_log_list[index]['url']][
                    'ip_dist'][filter_log_list[index]['ip']] = \
                    filter_log_list[index]['ip']
                article_table_dict[filter_log_list[index]['url']][
                    'ip_counts'] += 1

        # 这里要改为进程或携程
        # # 使用简易线程去请求文章标题
        # _logger.debug("start request url by thread：%s"
        # % article_table_dict.keys())
        # ts = [Thread(target=self._get_all_article_title,
        #              kwargs={'url': url,
        #                      'method': "GET",
        #                      'params': {},
        #                      'selector': {},
        #                      "article_table": article_dict})
        #       for url, article_dict in article_table_dict.items()
        #       if article_dict['url_type'] in DEFAULT_ARTICLE_URL_TYPE]
        # begin_time = time()
        # for t in ts:
        #     t.start()
        # for t in ts:
        #     t.join()
        # print("网络请求时间，总时间需减去：%s" % str(time() - begin_time))

        return article_table_dict

    def _get_ip_report(self, filter_log_list, start_index, end_index):
        """
        生成IP报表的内容
        :param filter_log_list:
        :return:
        """
        ip_table_dict = {}
        for index in range(start_index, end_index):
            if not filter_log_list[index]:
                continue
            if not ip_table_dict.get(filter_log_list[index]['ip']):
                ip_dict = {'ip': filter_log_list[index]['ip'],
                           'visits': 0,
                           'visits_article': 0,
                           'url_dist': {}}
                ip_table_dict[filter_log_list[index]['ip']] = ip_dict
            # 访问数+1
            ip_table_dict[filter_log_list[index]['ip']]['visits'] += 1
            # 没访问过的文章加入访问列表
            if filter_log_list[index]['type'] in DEFAULT_ARTICLE_URL_TYPE and \
                    not ip_table_dict[filter_log_list[index]['ip']][
                        'url_dist'].get(filter_log_list[index]['url']):
                ip_table_dict[filter_log_list[index]['ip']][
                    'visits_article'] += 1
                ip_table_dict[filter_log_list[index]['ip']][
                    'url_dist'][filter_log_list[index][
                        'url']] = filter_log_list[index]['url']
        return ip_table_dict

    def _get_complete_report(self, filter_log_list, start_index, end_index):
        """
        生成完整报表的内容
        :param filter_log_list:
        :return:
        """
        complete_table_dict = {}
        for index in range(start_index, end_index):
            if not filter_log_list[index]:
                continue
            key_ = "{ip}-{url}".format(ip=filter_log_list[index]['ip'],
                                       url=filter_log_list[index]['url'])
            if not complete_table_dict.get(key_):
                complete_dict = {'ip': filter_log_list[index]['ip'],
                                 'url': filter_log_list[index]['url'],
                                 'visits': 0}
                complete_table_dict[key_] = complete_dict
            complete_table_dict[key_]['visits'] += 1
        return complete_table_dict

    def get_article_report(self, filter_log_list):
        _logger.debug("driver start paste log, try to get article table")
        return self._get_table_by_pool(self._get_article_report,
                                       filter_log_list)

    def get_ip_report(self, filter_log_list):
        _logger.debug("driver start paste log, try to get ip table")

        return self._get_table_by_pool(self._get_ip_report,
                                       filter_log_list)

    def get_complete_report(self, filter_log_list):
        print(len(filter_log_list))
        _logger.debug("driver start paste log, try to get complete table")

        return self._get_table_by_pool(self._get_complete_report,
                                       filter_log_list)

class ExceptionBase(Exception):
    """错误基类"""
    error_code = ""
    msg = ""

    def __str__(self):
        return "%s %s" % (self.error_code, self.msg)


class NoIpOrUrlException(ExceptionBase):
    """没有匹配到ip或url"""
    error_code = "[0001]"
    msg = "can not find ip or url"


class NoSuffixException(ExceptionBase):
    """没有后缀名"""
    error_code = "[0002]"
    msg = "can not find suffix"

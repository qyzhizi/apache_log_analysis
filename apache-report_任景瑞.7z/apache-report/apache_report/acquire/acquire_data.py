# coding=utf-8
import logging
import os
import multiprocessing

from apache_report import exception
from apache_report.common.utils import set_logger

logger = set_logger(level=logging.DEBUG)


def get_data(filename):
    """可抽离成为输入数据模块"""
    # read file
    data_file = \
        ''.join([os.path.abspath(os.path.dirname(__file__)), '\\', filename])
    try:
        with open(data_file, 'r') as df:
            log_data = df.readlines()
    except IOError:
        logger.error("文件读取错误")
        raise exception.FileNotFoundException()
    return log_data


def get_data_multi_proc():
    """多进程读取多个log文件"""
    # 将多个log合并或者形成嵌套列表
    from apache_report.common.common_variables import cfg
    data_file = cfg.get('FILE', 'test_log_file')
    # 可能是列表
    pool = multiprocessing.Pool(5)
    data_file = data_file.strip('[|]')
    data_file = data_file.split(',')
    for f in data_file:
        pool.apply(func=get_data, args=(f,))
    log_list = pool.map(get_data)
    pool.close()
    pool.join()
    return log_list


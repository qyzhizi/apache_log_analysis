# -*- coding: utf-8 -*-

import unittest
import re
import time

from ApacheLogParser.parser.parser import ApacheLogParser
from ApacheLogParser.parser.parser import DataManager
from ApacheLogParser.data.create_data import LogMock
from ApacheLogParser.common.common import FILTER_URL


class TestProcessing(unittest.TestCase):
    """
    日志解析测试类
    """

    def setUp(self):
        pass

    def tearDown(self):
        print("Do something after test. Clean up.")

    def test_mock_data(self):
        t = LogMock()
        records = t.mock_records()
        res = t.save_mock_log(records)
        self.assertIsNone(res)

    def test_read_log_success(self):
        file_name = '/Users/mting/Desktop/LogParser/ApacheLogParser/data/apache.log'
        res = DataManager.load_log(file_name)
        self.assertIsInstance(res, list)

    @staticmethod
    def check_ip(ip):
        p = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
        if p.match(ip):
            return True
        else:
            return False

    @staticmethod
    def check_url(url):
        for black_type in FILTER_URL:
            if url.endswith(black_type):
                return False
        return True

    @staticmethod
    def check_performance(duration, default_duration=30):
        if duration < default_duration:
            return True
        else:
            return False

    # def test_2_gen_entire_reports(self):
    #     # 校验结果是不是[ip, url, access_times]的list
    #     res = ApacheLogParser().gen_entire_report()
    #     self.assertIsInstance(res, list)
    #     if len(res) > 0:
    #         [ip, url, access_times] = res[0]
    #         self.assertTrue(self.check_ip(ip))
    #         self.assertTrue(self.check_url(url))
    #         self.assertIsInstance(access_times, int)
    #
    # def test_3_gen_article_reports(self):
    #     # 校验是否为[url, title, access_count, access_ips]的lists
    #     res = ApacheLogParser().gen_article_report()
    #     self.assertIsInstance(res, list)
    #     if len(res) > 0:
    #         [url, title, access_count, access_ips] = res[0]
    #         self.assertTrue(self.check_url(url))
    #         # self.assertIs(title, str)
    #         self.assertIsInstance(access_count, int)
    #         self.assertIsInstance(access_ips, int)
    #
    # def test_4_gen_ip_reports(self):
    #     # 校验是否为 [ip, count, access_times]的list
    #     res = ApacheLogParser().gen_ip_report()
    #     self.assertIsInstance(res, list)
    #     if len(res) > 0:
    #         [ip, count, access_times] = res[0]
    #         self.assertTrue(self.check_ip(ip))
    #         self.assertIsInstance(count, int)
    #         self.assertIsInstance(access_times, int)

    def test_gen_entire_report(self):
        file_name = '/Users/mting/Desktop/LogParser/ApacheLogParser/data/apache.log'
        t1 = time.time()
        ApacheLogParser(file_name).gen_entire_report()
        duration = int(time.time() - t1)
        self.assertTrue(self.check_performance(duration))

    def test_gen_article_report(self):
        file_name = '/Users/mting/Desktop/LogParser/ApacheLogParser/data/apache.log'
        t2 = time.time()
        ApacheLogParser(file_name).gen_article_report()
        duration = int(time.time() - t2)
        self.assertTrue(self.check_performance(duration))

    def test_gen_ip_report(self):
        file_name = '/Users/mting/Desktop/LogParser/ApacheLogParser/data/apache.log'
        t3 = time.time()
        ApacheLogParser(file_name).gen_ip_report()
        duration = int(time.time() - t3)
        self.assertTrue(self.check_performance(duration))


if __name__ == '__main__':
    unittest.main()

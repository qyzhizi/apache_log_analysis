# -*- coding:utf-8 -*-
import os
import logging
from collections import defaultdict

from ApacheLogParser.utils.tool import get_title, unquote_title
from ApacheLogParser.common import common
from ApacheLogParser.utils.tool import gen_table
from ApacheLogParser.common import exceptions as exc

logger = logging.getLogger(__name__)
IP_INDEX = 0
URL_INDEX = 2


class DataManager(object):
    """对Apache日志进行信息提取"""

    def __init__(self):
        self.filter_list = []

    def parse_log(self, log_file):
        log_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), common.DATA_PATH, log_file)
        log_list = self.load_log(log_path)
        self.log_filter(log_list)

    @classmethod
    def load_log(cls, file_name):
        """
        加载文件.
        :param file_name: 文件名
        """
        try:
            with open(file_name) as f:
                return f.readlines()
        except IOError:
            logger.error("文件路径不存在")
            raise exc.LogFileNotFoundError

    @classmethod
    def check_url(cls, url):
        """
        检查url是否需要过滤
        """
        for end_type in common.FILTER_URL:
            if url.endswith(end_type):
                return False
        return True

    def log_filter(self, row_list):
        """
        对原始的log数据进行处理
        1. 删除错误数据格式
        2. 过滤后缀为js、css等后缀文件
        3. 将数据整合为[ip, method, url, status_code]格式
        :return: [[ip, method, url, status_code],...]
        """
        for line in row_list:
            # url_pattern = " /.*? "
            # ip_pattern = "(\d{1,3}\.){3}\d{1,3}"
            items = line.split(' ')
            url = items[6]
            if not self.check_url(url):
                continue
            ip, method, status = items[0], items[5], items[8]
            self.filter_list.append([ip, method, url, status])


class ApacheLogParser(object):
    """
    Apache日志分析器
    """
    def __init__(self, file_name):
        self.datamanager = DataManager()
        self.datamanager.parse_log(file_name)
        self.data_list = self.datamanager.filter_list

        # 多进程处理
        # self.datamanager = DataManager()
        # filelist = os.listdir(log_dir)
        # pool = multiprocessing.Pool(processes=4)
        # res = []
        # res = pool.map(self.datamanager.parse_log, filelist)
        # pool.close()
        # pool.join()
        # self.data_list = self.datamanager.filter_list

    def gen_article_report(self):
        """
        生成文章报表，|URL|文章标题|访问人次|访问IP数|
        :return: [[url, article_title, access_count, ip_num],...]
        """
        article_report_data = []
        # 用于统计url的访问人次，键为url，值为访问人次
        access_count_collector = defaultdict(int)
        # 用于统计url的访问ip数，键为url，值为存储ip的列表
        ip_num_collector = defaultdict(set)
        for record in self.data_list:
            access_count_collector[record[URL_INDEX]] += 1
            ip_num_collector[record[URL_INDEX]].add(record[IP_INDEX])
        for url_key in access_count_collector:
            title = url_key.split("/")[-1].split(".")[IP_INDEX]
            # if url_key.endswith('html') or url_key.endswith('htm'):
            #     # 请求接口获得title，并做异常捕获
            #     # 如果title不为None，就使用查询到的title
            #     url_title = get_title(url_key)
            #     if url_title:
            #         title = url_title
            title = unquote_title(title)
            article_report_data.append([url_key, title, access_count_collector[url_key], len(ip_num_collector[url_key])])
        gen_table("article_report", article_report_data)

    def gen_ip_report(self):
        """
        生成IP报表，|IP|访问次数|访问文章数|
        :return: [[ip, access_count, article_num],...]
        """
        ip_report_data = []
        # 用于统计ip的访问次数，键为ip，值为访问次数
        access_count_collector = defaultdict(int)
        # 用于统计ip的访问文章数，键为ip，值为访问的文章列表
        article_num_collector = defaultdict(set)
        for record in self.data_list:
            access_count_collector[record[IP_INDEX]] += 1
            article_num_collector[record[IP_INDEX]].add(record[URL_INDEX])
        for key in access_count_collector:
            access_count = access_count_collector[key]
            article_num = len(article_num_collector[key])
            ip_report_data.append([key, access_count, article_num])
        gen_table("ip_report", ip_report_data)

    def gen_entire_report(self):
        """
        生成完整报表，|IP|URL|访问次数|
        :return: [[ip, url, access_count],...]
        """
        entire_report_data = []
        # 用于统计ip和url的访问次数，键为ip和url的拼接字符，值为访问次数
        collector = defaultdict(int)
        for record in self.data_list:
            # 将ip和url进行拼接作为键值
            ip_url = '+'.join([record[IP_INDEX], record[URL_INDEX]])
            collector[ip_url] += 1
        for key in collector:
            [ip, url] = key.split('+')
            entire_report_data.append([ip, url, collector[key]])
        gen_table("entire_report", entire_report_data)






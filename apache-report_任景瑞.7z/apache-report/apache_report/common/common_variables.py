from apache_report.app.reporting.controller import ArticleManager
from apache_report.app.reporting.controller import IPReportManager
from apache_report.app.reporting.controller import CompleteReportManager
from apache_report.configs import load_config

suffix = ['js', 'css']
ArticleReport = 'article_table'
IPReport = 'ip_table'
CompleteReport = 'complete_table'

manager_dict = {ArticleReport: ArticleManager,
                IPReport: IPReportManager,
                CompleteReport: CompleteReportManager}

cfg = load_config.set_config()

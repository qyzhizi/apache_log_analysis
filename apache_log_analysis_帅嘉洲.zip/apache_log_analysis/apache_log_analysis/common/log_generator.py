import random

# 仿造apache_log数据
string_pattern = \
    '%s - - [16/Feb/2019:11:27:20 +0800] "GET %s HTTP/1.1" 200 12345\n'
ip_list = [
    "200.200.76.",
    "177.1.81."
]
url_list = [
    "/coding/miniprj/material.html",
    "/coding/gitbook/gitbook-plugin-search-plus/search.css",
    "/coding/gitbook/gitbook-plugin-disqus/plugin.css",
    "/coding/gitbook/gitbook-plugin-prism/prism-base16-ateliersulphurpool.light.css",
    "/coding/gitbook/style.css",
    "/coding/gitbook/gitbook-plugin-anchors/plugin.css",
    "/coding/gitbook/gitbook-plugin-emphasize/plugin.css",
    "/coding/gitbook/gitbook-plugin-expandable-chapters-small/expandable-chapters-small.css",
    "/coding/gitbook/gitbook-plugin-katex/katex.min.css",
    "/coding/gitbook/gitbook-plugin-splitter/splitter.css",
    "/coding/gitbook/gitbook-plugin-ace/ace.css",
    "/coding/gitbook/gitbook-plugin-donate/plugin.css",
    "/coding/gitbook/gitbook-plugin-sectionx/sectionx.css",
    "/coding/gitbook/gitbook-plugin-tbfed-pagefooter/footer.css",
    "/coding/gitbook/gitbook-plugin-local-video/video-js.min.css",
    "/coding/gitbook/gitbook-plugin-anchor-navigation-ex/style/plugin.css",
    "/coding/gitbook/gitbook-plugin-fontsettings/website.css",
    "/coding/gitbook/theme.js",
    "/coding/gitbook/gitbook-plugin-search-plus/search.js",
    "/coding/gitbook/gitbook-plugin-search-plus/jquery.mark.min.js",
    "/coding/gitbook/gitbook.js",
    "/coding/gitbook/gitbook-plugin-github/plugin.js",
    "/coding/gitbook/gitbook-plugin-github-buttons/plugin.js",
    "/coding/gitbook/gitbook-plugin-edit-link/plugin.js",
    "/coding/gitbook/gitbook-plugin-disqus/plugin.js",
    "/coding/gitbook/gitbook-plugin-ace/ace.js",
    "/coding/checklist/lang.html",
    "/coding/checklist/basic/phase2.html",
    "/coding/checklist/basic/debug.html",
    "/coding/checklist/domain.html",
    "/coding/basic/exercise.html",
    "/coding/style/whats-the-beautiful-code.html",
    "/coding/style/modularization.html"
]

log_path = \
        "C:/Users/asus/Desktop/入职/apache_log_analysis/apache_log_analysis/files/logs/apache_"

# 生成数据，大约1百万条110M
for i in range(1, 31):
    filename = log_path + ("%02d" % i) + ".log"

    with open(filename, "w") as f:
        for _ in range(300000):
            log_line = string_pattern % (random.choice(ip_list)+str(random.randint(50, 240)), random.choice(url_list))
            f.write(log_line)

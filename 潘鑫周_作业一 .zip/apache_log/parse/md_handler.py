# -*- coding: utf-8 -*-
from apache_log.common.const import IP_TABLE_HEAD
from apache_log.common.const import URL_TABLE_HEAD
from apache_log.common.const import LOG_TABLE_HEAD
from apache_log.common.utils import check_file
from apache_log.parse.exception import CheckDateError
from apache_log.parse.exception import CheckFileError


class MarkdownHandler(object):
    """
    markdown报表生成器
    作用: 解析报表所需要的信息(log_data，ip_data, url_data) 生成 markdown表单
    """

    def create_ip_md(self, ip_data, filename):
        u"""
        :param ip_data: 构造ip报表的数据
        :param filename: ip报表的存储路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)

        if not self.__check_ip_data(ip_data):
            raise CheckDateError("ip报表")

        ip_list = self.__transfer_ip_data(ip_data)
        self.__create_md(ip_list, IP_TABLE_HEAD, filename)

    def create_url_md(self, url_data, filename):
        u"""
        :param url_data: 构造文章报表的数据
        :param filename: 文章报表的存储路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)

        if not self.__check_url_data(url_data):
            raise CheckDateError("文章报表")

        url_list = self.__transfer_url_data(url_data)
        self.__create_md(url_list, URL_TABLE_HEAD, filename)

    def create_log_md(self, log_data, filename):
        u"""
        :param ip_data: 构造完整报表的数据
        :param filename: 完整报表的存储路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)

        if not self.__check_log_data(log_data):
            raise CheckDateError("完整报表")

        log_list = self.__transfer_log_data(log_data)
        self.__create_md(log_list, LOG_TABLE_HEAD, filename)

    def __create_md(self, table_data, table_head, filename):
        u"""
        创建 markdown报表的通用方法
        :param table_data: 构造报表的数据
        :param table_head: 报表的表头数据
        :param filename: 报表的存储路径
        :return: None
        """
        with open(filename, 'w') as f:
            # 构造表头
            f.write('\n')
            for i in range(len(table_head)):
                f.write(' | ' + table_head[i])
                if i == len(table_head) - 1:
                    f.write(' |')
            f.write('\n')
            f.write('| --- ' * len(table_head) + '|')
            # 构造表数据
            for row in table_data:
                f.write('\n')
                for i in range(len(row)):
                    f.write(' | ' + str(row[i]))
                    if i == len(table_head) - 1:
                        f.write(' |')

    def __transfer_ip_data(self, ip_data):
        u"""
        :param: ip_data: ip报表字典对象
        :return: ip_list ip报表列表对象
        """
        ip_list = []
        for k in ip_data:
            ip = k
            view_count = str(ip_data[k]['view_count'])
            topic_count = str(ip_data[k]['topic_count'])
            ip_item = [ip, view_count, topic_count]
            ip_list.append(ip_item)
        return ip_list

    def __transfer_url_data(self, url_data):
        u"""
        :param: url_data: 文章报表字典对象
        :return: url_list 文章报表列表对象
        """
        url_list = []
        for k in url_data:
            url = k
            name = url_data[k]['name']
            view_count = str(url_data[k]['view_count'])
            ip_count = str(url_data[k]['ip_count'])
            url_item = [url, name, view_count, ip_count]
            url_list.append(url_item)
        return url_list

    def __transfer_log_data(self, log_data):
        u"""
        :param: log_data: 完整报表字典对象
        :return: log_list 完整报表列表对象
        """
        log_list = []
        for k, v in log_data.items():
            ip = k[0]
            url = k[1]
            count = v
            log_item = [ip, url, count]
            log_list.append(log_item)
        return log_list

    def __check_ip_data(self, ip_data):
        u"""
        :param: ip_data: 检测ip报表的数据类型
        :return: bool 检查结果
        """
        res = False
        if isinstance(ip_data, dict):
            for k, v in ip_data.items():
                check_item = isinstance(k, str) and isinstance(v, dict)
                check_dict = isinstance(v['view_count'], int) and isinstance(v['topic_count'], int)
                res = check_item and check_dict
                if not res:
                    return res
        return res

    def __check_log_data(self, log_data):
        u"""
        :param: log_data: 构造完整报表的数据类型
        :return: bool 检查结果
        """
        res = False
        if isinstance(log_data, dict):
            for k, v in log_data.items():
                check_item = isinstance(k, tuple) and isinstance(v, int)
                check_tuple = isinstance(k[0], str) and isinstance(k[1], str)
                res = check_item and check_tuple
                if not res:
                    return res
        return res

    def __check_url_data(self, url_data):
        u"""
        :param: url_data: 构造文章报表的数据类型
        :return: bool 检查结果
        """
        res = False
        if isinstance(url_data, dict):
            for k, v in url_data.items():
                check_item = isinstance(k, str) and isinstance(v, dict)
                check_dict = isinstance(v['name'], str) and isinstance(v['view_count'], int) and isinstance(
                    v['ip_count'], int)
                res = check_item and check_dict
                if not res:
                    return res
        return res

import unittest
from apache_report.configs.load_config import set_config
from apache_report import exception


class TestLoadConfig(unittest.TestCase):
    def test_load_default_config(self):
        cfg = set_config()
        print(cfg)
        self.assertEqual(cfg.get('FILE', 'log_file'), 'apache_log.txt')

    def test_not_exist_config(self):
        self.assertRaises(exception.FileNotFoundException,
                          set_config, 'config1.ini')

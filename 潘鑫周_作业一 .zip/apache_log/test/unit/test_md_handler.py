# -*- coding: utf-8 -*-
import os
from unittest import TestCase

from apache_log.parse.md_handler import MarkdownHandler
from apache_log.parse.exception import CheckDateError


class TestMarkdownHandler(TestCase):

    def setUp(self):
        self.md = MarkdownHandler()

    def test_create_ip_md(self):
        # 测试ip报表生成
        ip_data = {
            "127.0.0.1": {
                "topic_count": 1,
                "view_count": 3,
            }
        }
        self.md.create_ip_md(ip_data, 'ip_data.md')
        res = os.path.exists('ip_data.md')
        self.assertTrue(res)
        os.remove('ip_data.md')
        false_ip_data = {
            "127.0.0.1": {
                "topic_count": "s",
                "view_count": 3,
            }
        }
        self.assertRaises(CheckDateError, self.md.create_ip_md, false_ip_data, 'ip_data.md')
        res = os.path.exists('ip_data.md')
        self.assertFalse(res)
        false_ip_data = {
            555: {
                "topic_count": "s",
                "view_count": "ssss",
            }
        }
        self.assertRaises(CheckDateError, self.md.create_ip_md, false_ip_data, 'ip_data.md')
        res = os.path.exists('ip_data.md')
        self.assertFalse(res)

    def test_create_url_md(self):
        # 测试url报表生成
        url_data = {
            "/coding/miniprj/material.html": {
                "name": "test",
                "view_count": 3,
                "ip_count": 7,
            }
        }
        self.md.create_url_md(url_data, 'url_data.md')
        res = os.path.exists('url_data.md')
        self.assertTrue(res)
        os.remove('url_data.md')
        false_url_data = {
            10089: {
                "name": "test",
                "view_count": "s",
                "ip_count": 7,
            }
        }
        self.assertRaises(CheckDateError, self.md.create_url_md, false_url_data, 'url_data.md')
        res = os.path.exists('url_data.md')
        self.assertFalse(res)
        false_url_data = {
            "/coding/miniprj/material.html": {
                "name": "test",
                "view_count": "s",
                "ip_count": "sasa",
            }
        }
        self.assertRaises(CheckDateError, self.md.create_url_md, false_url_data, 'url_data.md')
        res = os.path.exists('url_data.md')
        self.assertFalse(res)

    def test_create_log_md(self):
        # 测试完整报表生成
        log_data = {
            ("127.0.0.1", "/coding/miniprj/material.html"): 56
        }
        self.md.create_log_md(log_data, 'log_data.md')
        res = os.path.exists('log_data.md')
        self.assertTrue(res)
        os.remove('log_data.md')
        false_log_data = {
            (99, "/coding/miniprj/material.html"): "sa"
        }
        self.assertRaises(CheckDateError, self.md.create_log_md, false_log_data, 'log_data.md')
        res = os.path.exists('log_data.md')
        self.assertFalse(res)
        false_log_data = {
            (99, ""): ""
        }
        self.assertRaises(CheckDateError, self.md.create_log_md, false_log_data, 'log_data.md')
        res = os.path.exists('log_data.md')
        self.assertFalse(res)

    def tearDown(self):
        # 清理生成的报表
        if os.path.exists('ip_data.md'):
            os.remove('ip_data.md')
        if os.path.exists('url_data.md'):
            os.remove('url_data.md')
        if os.path.exists('log_data.md'):
            os.remove('log_data.md')

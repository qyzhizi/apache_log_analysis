package test

import (
	"github.com/PuerkitoBio/goquery"
	"net/http"
	"strings"
	"testing"
	"time"
)

func TestHTTP(t *testing.T) {
	client := http.Client{Timeout: time.Duration(30*time.Second)}
	res, _ := client.Get("http://200.200.1.35/coding/miniprj/material.html")
	doc, _ := goquery.NewDocumentFromReader(res.Body)
	find := doc.Find("html head title")
	println(find.Text())
}

func TestGoQuery(t *testing.T) {
	html := `
			<html>
			<head>
				<title>title1</title>
				<title>title2</title>
			</body>
			</head>
	`
	doc, _ := goquery.NewDocumentFromReader(strings.NewReader(html))
	find := doc.Find(" head title")
	println(find.First().Text())
}

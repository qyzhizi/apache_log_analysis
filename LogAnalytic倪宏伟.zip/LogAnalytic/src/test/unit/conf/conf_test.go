package test

import (
	"nhw-log/conf"
	"nhw-log/context"
	"testing"
)

func TestApplyConf(t *testing.T) {
	readConf := conf.ReadConf()
	reader := conf.LogRead(readConf)
	ctx := context.ApplyConf(readConf, reader)
	if len(ctx.Report)!= len(ctx.LogConf.Report.Content){
		t.Fatalf("read conf error")
	}
}

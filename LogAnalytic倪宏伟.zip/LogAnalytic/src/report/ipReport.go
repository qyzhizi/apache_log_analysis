package report

import (
	"fmt"
	"io"
	"nhw-log/common"
)

type IPReportContent struct {
	reqCount int
	article  map[string]bool
}

type IPReport struct {
	Report map[string]*IPReportContent
	Name   string
	title  []string
}

func (irep *IPReport) Finish() {
}

func (irep *IPReport) SetTitle(title []string) {
	irep.title = title
}

func (irep *IPReport) GetTitle() []string {
	return irep.title
}

func (irep *IPReport) Merge(report Report) {
	imap := report.Values().(map[string]*IPReportContent)
	for key, val := range imap {
		if irep.Report[key] == nil {
			irep.Report[key] = val
		} else {
			irep.Report[key].reqCount += val.reqCount
			for art, _ := range val.article {
				irep.Report[key].article[art] = true
			}
		}
	}

}

func (irep *IPReport) Values() interface{} {
	return irep.Report
}

func (irep *IPReport) Names() string {
	return irep.Name
}

func (irep *IPReport) Export(writer io.Writer, exportType string) {
	if exportType == common.MD {
		GenerateMDTitle(writer, irep.title)
		for ip, ipReportContent := range irep.Report {
			fmt.Fprintf(writer, "|%s|%d|%d|\n", ip, ipReportContent.reqCount, len(ipReportContent.article))
		}
	} else if exportType == common.HTML {
		GenerateHTMLTitle(writer,irep.title)
		for ip, ipReportContent := range irep.Report {
			fmt.Fprintf(writer, "<tr><td>%s</td><td>%d</td><td>%d</td></tr>\n", ip, ipReportContent.reqCount, len(ipReportContent.article))
		}

	}

}

//	IP地址应该是每个日志必须打印的就不用去正则获取了
func (irep *IPReport) Set(url string, ip string) {
	reportContent := irep.Report[ip]
	if reportContent != nil {
		reportContent.reqCount++
		reportContent.article[url] = true
	} else {
		irep.Report[ip] = &IPReportContent{
			reqCount: 1,
			article:  map[string]bool{url: true},
		}
	}
}

func (irep *IPReport) Init() {
	irep.Report = make(map[string]*IPReportContent)
	irep.Name = "ip"
}

package analytic

import (
	"log"
	"nhw-log/context"
	"nhw-log/report"
	"sync"
	"time"
)

type MultiThreadAnalytic struct {
	core int
}
type ThreadLocalData struct {
	LogData []byte
	Reports []report.Report
	count   int32
	mode    string
}

func (multiAnalytic MultiThreadAnalytic) LogAnalytic(ctx context.Context) {
	core := ctx.LogConf.Core
	// 设置核心数最大最小值为1到16
	if core == 0 {
		core = 1
	}
	if core > 16 {
		core = 16
	}
	var readTime int64
	start := time.Now().UnixNano()
	logData, next, delay := GetReaderRndDelay(ctx)
	readTime += delay
	for next {
		size := len(logData) / core
		tdatas := make([]*ThreadLocalData, core)
		var wg sync.WaitGroup
		for i := 0; i < core; i++ {
			wg.Add(1)
			tdatas[i] = &ThreadLocalData{mode: ctx.LogConf.ParserMode}
			tdata := tdatas[i]
			for _, rep := range ctx.LogConf.Report.Content {
				rep := report.GetReport(rep)
				rep.Init()
				tdata.Reports = append(tdata.Reports, rep)
			}
			if i != core-1 {
				tdata.LogData = logData[i*size : (i+1)*size]
			} else {
				tdata.LogData = logData[i*size:]
			}
			go func(i int) {
				SingleLogAnalytic(tdatas[i])
				defer wg.Done()
			}(i)
		}
		wg.Wait()
		for _, tdata := range tdatas {
			ctx.Count += tdata.count
			for _, re := range tdata.Reports {
				names := re.Names()
				ctxrep := ctx.Report[names]
				ctxrep.Merge(re)
			}
		}
		logData, next, delay = GetReaderRndDelay(ctx)
		readTime += delay
	}
	end := time.Now().UnixNano()
	for _, r := range ctx.Report {
		r.Finish()
	}

	log.Println("time consuming is  ", (end-start-readTime)/1000000, "ms")
	log.Println("count is ", ctx.Count)
	log.Println("---------LOG ANALYTIC SUCCESS!!!----------")

}

func GetReaderRndDelay(ctx context.Context) ([]byte, bool, int64) {
	readStart := time.Now().UnixNano()
	logData, next := ctx.Reader.NextRead()
	readEnd := time.Now().UnixNano()
	return logData, next, readEnd - readStart
}

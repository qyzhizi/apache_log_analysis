# -*- coding: utf-8 -*-

import os
from multiprocessing import Pool
from time import time

from apache_analyse.app.analyse.backends.driver import Resource
from apache_analyse.common.common import filter_log
from apache_analyse.common.log import get_log
from apache_analyse.common.constant import DEFAULT_APACHE_LOG_PATH, \
    ARTICLE_TABLE_CONFIG, IP_TABLE_CONFIG, COMPLETE_TABLE_CONFIG, \
    MAX_DIRECT_READ_SIZE, DEFAULT_WORKERS

_logger = get_log()


class DataManager:
    """文件读写管理器，
    可以选在是否以并发的方式来读取文件
    取决于你的机器性能
    支持读取目录
    """

    use_default_pool = False

    @classmethod
    def load(cls, file_path):
        """
        加载日志文件/目录
        :return:
        """
        _logger.debug("start read file: %s" % file_path)
        # 文件类型
        if os.path.isfile(file_path):
            return cls._read_file(file_path)

        # 如果是目录，开启进程去读取目录下的文件
        if os.path.isdir(file_path):
            pool = Pool(DEFAULT_WORKERS)
            jobs = []
            for files in os.listdir(file_path):
                jobs.append(pool.apply_async(cls._read_file, (files, )))

            res = [log_line for job in jobs for log_line in job.get()]
            pool.close()
            pool.join()
            return res

        _logger.exception("error file path: %s", file_path)
        raise Exception("非法的路径")

    @staticmethod
    def save(file_path, file_content):
        _logger.debug("start write file: %s" % file_path)

        with open(file_path, encoding="utf-8", mode="w") as f:
            f.write(file_content)

    @classmethod
    def _read_file(cls, file_path):
        # 关于单文件超过一定大小是否要并发读取问题
        # 我和两位导师讨论过，都给出了不同的意见
        # 这里保留两种方法
        if cls.use_default_pool and os.path.getsize(file_path) \
                > MAX_DIRECT_READ_SIZE:
            return cls._read_file_pool(file_path)
        else:
            return cls._read_file_direct(file_path)

    @staticmethod
    def _read_file_direct(file_name):
        """
        直接读取文件所有内容进缓存
        :param file_name:
        :return:
        """
        with open(file_name, 'r') as f:
            return f.readlines()

    @classmethod
    def _read_file_pool(cls, file_name):
        """
        以并发的方式读文件
        :param file_name:
        :return:
        """
        file_size = os.path.getsize(file_name)
        pool = Pool(DEFAULT_WORKERS)
        jobs = []
        for chuck_start, chunk_size in cls._chunk_file(file_name, file_size):
            jobs.append(pool.apply_async(cls._process_wrapper, (file_name,
                                                                chuck_start,
                                                                chunk_size)))
        res = [log_line for job in jobs for log_line in job.get()]
        pool.close()
        pool.join()
        return res

    @classmethod
    def _chunk_file(cls, file_name, file_ize):
        """
        获取每个子进程要读取文件的配置
        :param file_name:
        :param file_ize:
        :return:
        """
        with open(file_name, 'rb') as f:
            chuck_end = f.tell()
            while 1:
                chuck_start = chuck_end
                f.seek(MAX_DIRECT_READ_SIZE, 1)
                # 多读取一行，确保不会截断数据
                f.readline()
                chuck_end = f.tell()
                yield chuck_start, chuck_end - chuck_start
                if chuck_end > file_ize:
                    break

    @classmethod
    def _process_wrapper(cls, file_path, chuck_start, chunk_size):
        """
        并行读取文件
        :param chuck_start: 开始读的位置
        :param chunk_size: 读的大小
        :return:
        """
        with open(file_path, 'r') as f:
            f.seek(chuck_start)
            content = f.read(chunk_size).splitlines()
            return content


class ApacheAnalyse:
    """生成对应的报表"""

    def __init__(self, file_path=DEFAULT_APACHE_LOG_PATH):
        self.log_list = DataManager.load(file_path)
        self.filter_log_list = filter_log(self.log_list)
        self.driver = Resource()

    @staticmethod
    def _record(table_dict, table_config):
        """
        反序列化写入文件
        :param table_dict:
        :param table_config:
        """
        _logger.debug("Start report%s" % table_config[0])

        content_list = [table_config[1]]
        for table_ in table_dict.values():
            content_list.append(table_config[2]
                                .format(**table_))

        DataManager.save(table_config[0], '\n'.join(content_list))

    def get_article_report(self):
        """
        生成文章报表
        :return:
        """
        _logger.debug("start request article table api")

        article_table_dict = self.driver.get_article_report(
            self.filter_log_list)
        self._record(article_table_dict, ARTICLE_TABLE_CONFIG)
        return article_table_dict

    def get_ip_report(self):
        """
        生成IP报表
        :return:
        """
        _logger.debug("start request ip table api")

        ip_table_dict = self.driver.get_ip_report(self.filter_log_list)
        self._record(ip_table_dict, IP_TABLE_CONFIG)
        return ip_table_dict

    def get_complete_report(self):
        """
        生成完整报表
        :return:
        """
        _logger.debug("start request complete table api")

        complete_table_dict = self.driver.\
            get_complete_report(self.filter_log_list)
        self._record(complete_table_dict, COMPLETE_TABLE_CONFIG)
        return complete_table_dict

    def main(self):
        pass


if __name__ == '__main__':
    begin_time = time()
    end_time = time()
    apache_analyse = ApacheAnalyse()
    print("读取时间：%s" % str(time()-end_time))
    end_time = time()
    apache_analyse.get_article_report()
    print("生成文章报表时间：%s" % str(time() - end_time))
    end_time = time()
    apache_analyse.get_ip_report()
    print("生成ip报表时间：%s" % str(time() - end_time))
    end_time = time()
    apache_analyse.get_complete_report()
    print("生成完整报表时间：%s" % str(time() - end_time))
    end_time = time()
    print("总时间：%s" % str(time() - begin_time))

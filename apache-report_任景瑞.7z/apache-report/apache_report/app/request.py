# coding=utf-8
import urllib2

from lxml import etree

from apache_report.common.utils import match_string
from apache_report.configs import load_config

cfg = load_config.set_config()
host_ip = cfg.get('HOST', 'IP')


class RequestStore(object):
    """存储请求信息类 可根据需要信息扩展(继承或修改)"""
    def __init__(self, ip, log_time, method, url, status=None, title=None):
        self.ip = ip
        self.time = log_time
        self.method = method
        self.url = url
        self.status = status
        self.title = title

    def serializing_req(self):
        return [self.ip, self.url, self.title]

    def get_req_key_info(self):
        return [self.ip, self.url]


def get_article_name(url):
    """获取页面标题文件名称"""
    name = url[url.rfind('/'):]
    # 如果时页面文件，返回文章标题
    if match_string(url, 'html') or match_string(url, 'htm'):
        # 获得页面标题
        page = ''.join([host_ip, url])
        title = _get_url_title(page)
        if title == page:
            return name[:name.find('.')]
        else:
            return title
    # 不是页面文件返回文件名称
    return name


def _get_url_title(url):
    # 远程访问获取http请求
    def get_site_title(link):
        send_headers = {
            'User-Agent':
                'ip',
            'Accept':
                'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;',
            'Connection': 'keep-alive'
        }  # 伪装header
        try:  # 异常处理
            title = etree.HTML(urllib2.urlopen(
                urllib2.Request(link, headers=send_headers)).read().decode(
                'utf-8')).xpath("/html/head/title")[0].text
        except ValueError:
            return link
        return title[0].text
    return get_site_title(url)

# TODO 扩展获取更多信息

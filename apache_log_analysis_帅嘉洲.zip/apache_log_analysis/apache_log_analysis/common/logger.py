import logging
import os

# 路径，为父目录的同级目录
FILES_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGGING_FILE = os.path.join(FILES_DIR, "apache_log_analysis.log")


class Logger(object):
    def __init__(self):
        log_format = "%(asctime)s [%(levelname)s] %(filename)s %(lineno)d " \
                     "%(funcName)s \n%(message)s"
        logging.basicConfig(
            filename=LOGGING_FILE,
            level=logging.DEBUG,
            format=log_format
        )
        self.log = logging.getLogger("Analysis")

    def get_logger(self):
        return self.log

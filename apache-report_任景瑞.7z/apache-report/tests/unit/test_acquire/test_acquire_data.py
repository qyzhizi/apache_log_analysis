import unittest
from apache_report.acquire.acquire_data import get_data
from apache_report import exception


class TestGetData(unittest.TestCase):
    def test_have_file(self):
        res = get_data('apache_log.txt').strip('\n')
        self.assertEqual(res,
                         '200.200.76.130 - - [16/Feb/2019:11:27:20 +0800] '
                         '"GET /coding/miniprj/material.html HTTP/1.1" '
                         '200 38093')

    def test_no_file(self):
        self.assertRaises(exception.FileNotFoundException,
                          get_data,
                          '')



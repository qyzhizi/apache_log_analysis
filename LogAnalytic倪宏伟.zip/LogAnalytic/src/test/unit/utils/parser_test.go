package test

import (
	"nhw-log/utils"
	"regexp"
	"testing"
)

var urlReg = regexp.MustCompile(`(\S)*(htm|docx|pdf|doc|mpg|zip)`)
var ipReg = regexp.MustCompile(`((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[09][0-9]|[1-9][0-9]|[0-9])`)

func TestGetIPBySplit(t *testing.T) {
	ip := utils.GetIPBySplit("200.200.3.6 ibisq")
	if ip != "200.200.3.6" {
		t.Fatalf("paser ip error ")
	}
}

func TestGetUrlBySplit(t *testing.T) {
	ip := utils.GetIPBySplit("/ubwdbwu.html sw")
	if ip != "/ubwdbwu.html" {
		t.Fatalf("paser ip error ")
	}
}

func TestGetIPByRegular(t *testing.T) {
	ip := utils.GetIPBySplit("200.200.3.6 ibisq")
	if ip != "200.200.3.6" {
		t.Fatalf("paser ip error ")
	}
}

func TestGetUrlByRegular(t *testing.T) {
	ip := utils.GetIPBySplit("/ubwdbwu.html sw")
	if ip != "/ubwdbwu.html" {
		t.Fatalf("paser ip error ")
	}
}

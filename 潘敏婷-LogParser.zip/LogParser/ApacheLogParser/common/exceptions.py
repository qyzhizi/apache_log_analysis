# -*- coding:utf-8 -*-

class TypeDataMismatchError(Exception):

    def __str__(self):
        return "Report type mismatch input data, please check carefully."


class ReportTypeInvalidError(Exception):

    def __str__(self):
        return "Input report type not found, please check carefully."


class ReportRecordsEmptyError(Exception):

    def __str__(self):
        return "Input records are empty, please input valid records."


class LogFileNotFoundError(Exception):

    def __str__(self):
        return "文件不存在，请检查！"

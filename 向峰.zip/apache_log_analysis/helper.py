import re
from typing.io import TextIO

import requests


# 获取页面标题
def get_page_title(url: str) -> str:
    res = requests.get(url)
    if res:
        title = re.findall(r"(?<=<title>).*?(?=</title>)", res.text)[0]
        if title:
            return title
    return 'Not Found'


# 提取ip和url
def get_ip_add_and_url(line: str, file_filter: list) -> tuple:
    if not line:
        return None
    split_line = line.split(b'GET ', 2)
    if len(split_line) == 1:
        return None
    ip_add = split_line[0].split(b' - - ')[0]
    # 先分离出全部文件格式
    url = split_line[1].split(b' ', 2)[0]
    file_type = url.split(b'.')[-1]
    if file_type not in file_filter:
        return None
    return ip_add, url


def write_markdown_table(file_path: str, headers: list, align: str):
    with open(file_path, "w") as file:
        table_header = '|' + ' | '.join(headers) + '|\n'
        dividers = {
            'l': ':----',
            'c': ':----:',
            'r': '----:'
        }
        table_divider = '|' + '|'.join([dividers[align] * len(headers)]) + '|'
        file.writelines([table_header, table_divider])
        return file

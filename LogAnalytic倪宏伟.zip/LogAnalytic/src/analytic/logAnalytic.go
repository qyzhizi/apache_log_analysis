package analytic

import (
	"nhw-log/context"
	"runtime"
)

type Analytic interface {
	LogAnalytic(ctx context.Context)
}

func Analyticlog(ctx context.Context) {
	core := ctx.LogConf.Core
	// CPU密集型应用设置协程数为CPU核心数+1
	if core == 0 {
		core = runtime.NumCPU() + 1
	}
	analytic := MultiThreadAnalytic{core: ctx.LogConf.Core}
	analytic.LogAnalytic(ctx)
}

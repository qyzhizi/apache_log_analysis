# -*- coding: utf-8 -*-
LOG_FILE = "./log/"
IP_MD_FILE = "./markdown/ip.md"
URL_MD_FILE = "./markdown/url.md"
LOG_MD_FILE = "./markdown/log.md"
ENDPOINT = "http://200.200.1.35"

IP_TABLE_HEAD = ["IP", "访问次数", "访问文章数"]
URL_TABLE_HEAD = ["URL", "文章标题", "访问人次", "访问IP数"]
LOG_TABLE_HEAD = ["IP", "URL", "访问人次"]

TOPIC_FILTER = ('html', 'htm', 'doc', 'docx', 'pdf')
FILE_FILTER = ('.css', '.js', '.zip')

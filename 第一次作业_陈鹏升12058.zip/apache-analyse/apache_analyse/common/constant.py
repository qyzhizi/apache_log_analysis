# 存放信息的文件路径
APACHE_FILE_PATH = (
    DEFAULT_APACHE_LOG_PATH,
    DEFAULT_PUBLIC_LOG_FILE_NAME,
    DEFAULT_ERROR_LOG_FILE_NAME
) = (
    r"E:\python_project\apache-analyse\apache.log",
    r"E:\python_project\apache-analyse\public.log",
    r"E:\python_project\apache-analyse\error.log"
)

# 日志的记录格式
LOG_FORMAT = (
    DEFAULT_PUBLIC_LOG_FORMATTER,
    DEFAULT_ERROR_LOG_FORMATTER
) = (
    "%(asctime)s - %(levelname)s - %(message)s",
    "%(asctime)s - %(levelname)s - %(filename)s[:%(lineno)d] - %(message)s"
)

# 没实现网络请求接口前的默认的返回数据
URL_RESPONSE = {
    'GET': "This is get response",
    'POST': "This is post response",
    'HEAD': "This is head response",
    'DELETE': "This is delete response",
}

# 没实现解析网页的具体内容前默认的返回数据
URL_ATTR_RESPONSE = {
    'GET': "This is get attr",
    'POST': "This is post attr",
    'HEAD': "This is head attr",
    'DELETE': "This is delete attr"

}

COMPLETE_TABLE_CONFIG = (
    DEFAULT_APACHE_COMPLETE_TABLE_PATH,
    DEFAULT_COMPLETE_TABLE_TITLE_FORMAT,
    DEFAULT_COMPLETE_TABLE_CONTENT_FORMAT
) = (
    r"E:\python_project\apache-analyse\complete_table.md",
    "| IP   | URL |  访问次数 |\n|------|-----|-----------|",
    "|{ip} | {url} | {visits} |"
)

IP_TABLE_CONFIG = (
    DEFAULT_APACHE_IP_TABLE_PATH,
    DEFAULT_IP_TABLE_TITLE_FORMAT,
    DEFAULT_IP_TABLE_CONTENT_FORMAT
) = (
    r"E:\python_project\apache-analyse\ip_table.md",
    "| IP  |  访问次数 | 访问文章数 |\n|-----|-----------|------------|",
    "|{ip} | {visits} | {visits_article} |",
)

ARTICLE_TABLE_CONFIG = (
    DEFAULT_APACHE_ARTICLE_TABLE_PATH,
    DEFAULT_ARTICLE_TABLE_TITLE_FORMAT,
    DEFAULT_ARTICLE_TABLE_CONTENT_FORMAT
) = (
    r"E:\python_project\apache-analyse\article_table.md",
    "| URL  | 文章标题 | 访问人次   | 访问IP数 |\n"
    "|------|----------|------------|----------|",
    "|{url} | {title} | {visits} | {ip_counts} |"
)

# mock时patch的公共路径
COMMON_MOCK_PATH = "apache_analyse"


FILTER_URL_TYPE = (
    DEFAULT_REMOVE_URL_TYPE,
    DEFAULT_ARTICLE_URL_TYPE
) = (
    ('css', 'js'),
    ['html', 'htm']
)

# 清洗数目超过这个开启子进程处理
MAX_DIRECT_FILTER_SIZE = 1000*1000
# 报表数目超过这个开启子进程处理
MAX_DIRECT_TABLE_SIZE = 1000*900
# 文件每次的最大读取
MAX_DIRECT_READ_SIZE = 1024*1024
# 默认进程数
DEFAULT_WORKERS = 6

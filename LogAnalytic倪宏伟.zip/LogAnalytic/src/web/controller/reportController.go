package web

import (
	"net/http"
	"nhw-log/common"
	"nhw-log/report"
)

type ReportController struct {
	ReportMap map[string]report.Report
}

func (controller *ReportController) GetIP(writer http.ResponseWriter, request *http.Request) {
	controller.ReportMap[common.IP].Export(writer, common.HTML)
}

func (controller *ReportController) GetArticle(writer http.ResponseWriter, request *http.Request) {
	controller.ReportMap[common.ARTICLE].Export(writer, common.HTML)
}

func (controller *ReportController) GetALL(writer http.ResponseWriter, request *http.Request) {
	controller.ReportMap[common.ALL].Export(writer, common.HTML)
}

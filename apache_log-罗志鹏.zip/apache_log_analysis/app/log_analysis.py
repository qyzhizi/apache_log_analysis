# -*- coding: utf-8 -*-
import re
from time import time

from apache_log_analysis.common.data_models import LogNames
from apache_log_analysis.common.data_models import FileType
from apache_log_analysis.common.data_models import ArticleReportDate
from apache_log_analysis.common.data_models import IpReportData
from apache_log_analysis.common.data_models import WholeReportDate
from apache_log_analysis.common.config import get_log
from apache_log_analysis.common.config import DEFAULT_TITLE
from apache_log_analysis.common.config import ARTICLE_TITLE_FORMAT
from apache_log_analysis.common.config import ARTICLE_LINE_FORMAT
from apache_log_analysis.common.config import IP_TITLE_FORMAT
from apache_log_analysis.common.config import IP_LINE_FORMAT
from apache_log_analysis.common.config import WHOLE_TITLE_FORMAT
from apache_log_analysis.common.config import WHOLE_LINE_FORMAT

logger = get_log()

def get_title(url):
    u""" 获取url的标题.

    :param url
    """
    return DEFAULT_TITLE


class DataHander(object):
    def __init__(self):
        pass

    # @staticmethod
    # def load(file_path):
    #     """
    #     读取文件内容
    #     :param file_path: 文件路径
    #     :return: 文件内容
    #     """
    #     _logger.debug("开始读取文件%s" % file_path)
    #
    #     if not os.path.exists(file_path):
    #         _logger.exception("%s文件不存在" % file_path)
    #         raise ErrorNotExistsFile(file_path)
    #
    #     with open(file_path, mode="r") as f:
    #         return f.readlines()

    @staticmethod
    def save(file_path, file_content):
        with open(file_path, mode="w") as f:
            f.write(file_content)


class LogAnalysis(object):
    def __init__(self, log_file, re_log_line_pattern):
        self.log_file = log_file
        self.re_log_line_pattern = re_log_line_pattern
        self.log_preprocess_result = []
        self.article_report_data = ArticleReportDate()
        self.ip_report_data = IpReportData()
        self.whole_report_data = WholeReportDate()
        self.article_report_data_flg = False
        self.ip_report_data_flg = False
        self.whole_report_data_flg = False
        self.get_report_data_flg = False

    def _split_log(self, log_file, re_log_line_pattern):
        u""" 使用正则表达式拆分字符串，输出预处理后的日志信息

        :param log_file: 日志文件
        :param re_log_line_pattern: 正则化模式
        """

        with open(log_file) as f:  # TODO 文件异常
            for eachLine in f:
                line_result = re.findall(re_log_line_pattern, eachLine, re.I)
                # line_result = eachLine.split()
                # if len(line_result)==10:
                #     self.log_preprocess_result.append([line_result[0],
                #                                        line_result[5][1:],
                #                                        line_result[6],
                #                                        line_result[6][-4:]])
                if line_result:
                    self.log_preprocess_result.append(line_result[0])
        print(self.log_preprocess_result)

    def _get_article_report_data(self, log_preprocess_result):
        u""" 处理日志，获取针对文章报表的信息.

            :param log_preprocess_result: 预处理后的日志信息
        """

        for item in log_preprocess_result:
            url = LogNames.URL
            ip = LogNames.IP

            if item[LogNames.FILE_TYPE] in FileType.type1:
                # {url_1: nums1, url_2: nums2, ...}
                self.article_report_data.url_num[item[url]] = \
                    self.article_report_data.url_num.get(item[url], 0) + 1
                # {url_1: {ip1, ip2,...}, rul_2: {ip1, ip2,...}}
                if item[url] not in self.article_report_data.url_ip:
                    self.article_report_data.url_ip[item[url]] = {item[ip]}
                else:
                    self.article_report_data.url_ip[item[url]].add(item[ip])
                if item[url] not in self.article_report_data.url_title:
                    self.article_report_data.url_title[item[url]] = get_title(
                                                              item[url])
        self.article_report_data_flg = True
        return self.article_report_data

    def _get_ip_report_data(self, log_preprocess_result):
        u""" 处理日志，获取针对ip报表的信息.

            :param log_preprocess_result: 预处理后的日志信息
        """
        for item in log_preprocess_result:
            ip = LogNames.IP
            file_type = LogNames.FILE_TYPE
            ip_nums = self.ip_report_data.IP_NUMS
            ip_articles = self.ip_report_data.IP_ARTICLES

            ip_report_dict = self.ip_report_data.ip_report_dict
            if item[ip] not in ip_report_dict:
                ip_report_dict[item[ip]] = {ip_nums: 1, ip_articles: 0}
            else:
                ip_report_dict[item[ip]][ip_nums] += 1
            if item[file_type] in FileType.type1:
                ip_report_dict[item[ip]][ip_articles] += 1
        self.ip_report_data_flg = True
        return self.ip_report_data

    def _get_whole_report_data(self, log_preprocess_result):
        u""" 处理完整报表数据，获取完整的报表数据

            :param log_preprocess_result: 预处理后的日志信息
        """
        for item in log_preprocess_result:
            ip = LogNames.IP
            url = LogNames.URL
            whole_report_dict = self.whole_report_data.whole_report_dict
            if item[ip] not in whole_report_dict:
                whole_report_dict[item[ip]] = {item[url] : 1}
            elif item[url] not in whole_report_dict[item[ip]]:
                whole_report_dict[item[ip]][item[url]] = 1
            else:
                whole_report_dict[item[ip]][item[url]] += 1
        self.whole_report_data_flg = True
        return self.whole_report_data

    def article_report(self, save_path):
        u""" 处理文章报表数据，生成文章类型的报表

            :param save_path: 保存路径
        """
        # log 预处理
        if not self.log_preprocess_result:
            begin_time = time()
            self._split_log(self.log_file, self.re_log_line_pattern)
            logger.debug("日志预处理时间：%s" % str(time() - begin_time))
        # article report data
        if not self.article_report_data_flg:
            begin_time = time()
            self._get_article_report_data(self.log_preprocess_result)
            logger.debug("生成文章报表数据时间：%s" % str(time() - begin_time))

        # generate article report
        data = self.article_report_data
        content_list = [ARTICLE_TITLE_FORMAT]
        for url_key in data.url_num:
            content_list.append(ARTICLE_LINE_FORMAT.format(url=url_key,
                            title=data.url_title[url_key],
                            visit_nums=data.url_num[url_key],
                            ip_nums=len(data.url_ip[url_key])
                            )
            )
        DataHander.save(save_path, '\n'.join(content_list))

    def ip_report(self, save_path):
        u""" 处理ip报表数据，生成ip类型的报表

            :param save_path: 保存路径
        """
        # log 预处理
        if not self.log_preprocess_result:
            begin_time = time()
            self._split_log(self.log_file, self.re_log_line_pattern)
            logger.debug("日志预处理时间：%s" % str(time() - begin_time))
        # ip report data
        if not self.ip_report_data_flg:
            begin_time = time()
            self._get_ip_report_data(self.log_preprocess_result)
            logger.debug("生成IP报表数据时间：%s" % str(time() - begin_time))
            # print("IP报表数据:", self.ip_report_data.ip_report_dict)
        # generate ip report
        content_list = [IP_TITLE_FORMAT]
        ip_report_dict = self.ip_report_data.ip_report_dict
        ip_nums = self.ip_report_data.IP_NUMS
        ip_articles = self.ip_report_data.IP_ARTICLES

        for ip_key in ip_report_dict:
            content_list.append(IP_LINE_FORMAT.format(ip=ip_key,
                            visit_nums=ip_report_dict[ip_key][ip_nums],
                            article_nums=ip_report_dict[ip_key][ip_articles])
                            )
        DataHander.save(save_path, '\n'.join(content_list))

    def whole_report(self, save_path):
        u""" 处理完整报表数据，生成完成的报表

            :param save_path: 保存路径
        """
        # log 预处理
        if not self.log_preprocess_result:
            begin_time = time()
            self._split_log(self.log_file, self.re_log_line_pattern)
            logger.debug("日志预处理时间：%s" % str(time() - begin_time))
        # whole report data
        if not self.whole_report_data_flg:
            begin_time = time()
            self._get_whole_report_data(self.log_preprocess_result)
            logger.debug("生成完整报表数据时间：%s" % str(time() - begin_time))
            # print("完整报表数据: ", self.whole_report_data.whole_report_dict)

        # generate whole report
        content_list = [WHOLE_TITLE_FORMAT]
        whole_report_dict = self.whole_report_data.whole_report_dict

        for ip_key in whole_report_dict:
            for url in whole_report_dict[ip_key]:
                nums = whole_report_dict[ip_key][url]
                content_list.append(WHOLE_LINE_FORMAT.format(ip=ip_key,
                                                         url=url,
                                                        visit_nums=nums))
        DataHander.save(save_path, '\n'.join(content_list))


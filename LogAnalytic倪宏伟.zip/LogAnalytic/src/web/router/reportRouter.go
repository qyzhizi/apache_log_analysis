package web

import (
	"net/http"
	"nhw-log/report"
	web2 "nhw-log/web/controller"
)

func Router(mux *http.ServeMux, reportMap map[string]report.Report) {
	controller := web2.ReportController{ReportMap: reportMap}
	mux.HandleFunc("/ip", controller.GetIP)
	mux.HandleFunc("/article", controller.GetArticle)
	mux.HandleFunc("/all", controller.GetALL)
}

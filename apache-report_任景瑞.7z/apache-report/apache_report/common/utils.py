# coding=utf-8
import logging
import sys
import re

from apache_report import exception


def set_logger(name='apache-report', level=logging.DEBUG):
    """ 初始化logger并设置默认级别为"DEBUG"

    Returns:
        logging.Logger: a logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger_format = logging.Formatter(
        "[%(asctime)s] %(pathname)s %(funcName)s %(lineno)s"
        " %(levelname)s: %(message)s",
        datefmt="%m/%d %H:%M:%S")
    try:
        file_handler = logging.StreamHandler(stream=sys.stdout)
        file_handler.setFormatter(logger_format)
        logger.addHandler(file_handler)
    except IOError:
        raise exception.CommonOutputException("初始化logger失败")
    finally:
        return logger


def match_string(src, dst):
    """匹配目标后缀是否在字符串中
    :param: src: 待匹配字符串
    :param: dst: 需查找字符模式
    """
    if '.' not in dst:
        dst = ''.join(['.', dst])
    suffix = src[src.rfind('.'):]
    if re.match(dst, suffix):
        return True
    return False


def valid_url(un_url):
    """判断是否为有效URL"""
    if un_url == '*':
        return False
    url_pattern = re.compile(r'/([a-zA-Z0-9]).*\.')
    rs = url_pattern.match(un_url)
    if not rs:
        return False
    return True


def valid_ip(un_ip):
    """判断是否为有效ip地址"""
    ip_num = r'(([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.){3}' \
             r'([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])$'
    pattern = re.compile(ip_num)
    rs = pattern.match(un_ip)
    if not rs:
        return False
    return True

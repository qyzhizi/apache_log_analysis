# -*- coding: utf-8 -*-
import re
import os
import requests
from unittest import TestCase

from apache_log.parse.log_handler import LogHandler
from apache_log.parse.exception import CheckFileError
from apache_log.common.utils import parse_line
from apache_log.common.utils import get_topic_name
from apache_log.common.utils import get_html_title
from apache_log.common.const import ENDPOINT


class TestLogHandler(TestCase):

    def setUp(self):
        self.log_file = "../../log/test2.log"
        self.log = LogHandler(self.log_file)

    def test_parse_line(self):
        # 检验解析日志文件行
        line = """
        200.200.76.130 - - [16/Feb/2019:11:27:20 +0800] 
        "GET /coding/gitbook/gitbook-plugin-fontsettings/fontsettings.js HTTP/1.1" 200 6447
        """
        ip, url = parse_line(line)
        self.assertIsInstance(ip, str)
        self.assertIsInstance(url, str)
        self.assertEqual(ip, "200.200.76.130")
        self.assertEqual(url, "/coding/gitbook/gitbook-plugin-fontsettings/fontsettings.js")

    def test_get_topic_name(self):
        # 检验获取文章的名称
        endpoint = ENDPOINT
        url1 = "/dashboard/howto.html"
        url2 = "/dashboard/pxz.docx"
        name1 = get_topic_name(url1, endpoint)
        name2 = get_topic_name(url2, endpoint)
        html_title = get_html_title(url1, endpoint)
        self.assertEqual(name1, html_title)
        self.assertEqual(name2, 'pxz.docx')

    def test_get_html_title(self):
        # 检验获取html中的title标签
        url = "/dashboard/howto.html"
        endpoint = ENDPOINT
        name = get_html_title(url, endpoint)
        html = requests.get(self.log.endpoint + url).text
        pattern = '<title>(.+?)</title>'
        html_title = re.findall(pattern, html)[0][2:-1]
        self.assertEqual(name, html_title)

    def test_get_log_data(self):
        # 检验 log_data 获取
        log_data = self.log.get_log_data()
        self.assertIsNotNone(log_data)
        # 检验 log_data 数据类型
        self.assertIsInstance(log_data, dict)
        for k, v in log_data.items():
            self.assertIsInstance(k, tuple)
            self.assertIsInstance(k[0], str)
            self.assertIsInstance(k[1], str)
            self.assertIsInstance(v, int)

    def test_get_ip_data(self):
        # 检验 ip_data 获取
        ip_data = self.log.get_ip_data()
        self.assertIsNotNone(ip_data)
        # 检验 ip_data 数据类型
        self.assertIsInstance(ip_data, dict)
        for k, v in ip_data.items():
            self.assertIsInstance(k, str)
            self.assertIsInstance(v, dict)
            self.assertIsInstance(v['topic_count'], int)
            self.assertIsInstance(v['view_count'], int)

    def test_get_url_data(self):
        # 检验 url_data 获取
        url_data = self.log.get_url_data()
        self.assertIsNotNone(url_data)
        # 检验 url_data 数据类型
        for k, v in url_data.items():
            self.assertIsInstance(k, str)
            self.assertIsInstance(v, dict)
            self.assertIsInstance(v['name'], str)
            self.assertIsInstance(v['view_count'], int)
            self.assertIsInstance(v['ip_count'], int)

    def test_create_ip_md(self):
        # 测试ip报表的生成
        self.log.create_ip_md('ip.md')
        res = os.path.exists('ip.md')
        self.assertTrue(res)
        self.assertRaises(CheckFileError, self.log.create_ip_md, 'ip.textxtx')
        res = os.path.exists('ip.textxtx')
        self.assertFalse(res)

    def test_create_url_md(self):
        # 测试url报表的生成
        self.log.create_ip_md('url.md')
        res = os.path.exists('url.md')
        self.assertTrue(res)
        self.assertRaises(CheckFileError, self.log.create_ip_md, 'url.textxtx')
        res = os.path.exists('url.textxtx')
        self.assertFalse(res)

    def test_create_log_md(self):
        # 测试完整报表的生成
        self.log.create_log_md('log.md')
        res = os.path.exists('log.md')
        self.assertTrue(res)
        self.assertRaises(CheckFileError, self.log.create_ip_md, 'log.textxtx')
        res = os.path.exists('log.textxtx')
        self.assertFalse(res)

    def tearDown(self):
        # 清理生成的报表
        if os.path.exists('ip.md'):
            os.remove('ip.md')
        if os.path.exists('url.md'):
            os.remove('url.md')
        if os.path.exists('log.md'):
            os.remove('log.md')

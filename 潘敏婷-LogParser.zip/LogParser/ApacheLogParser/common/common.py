DATA_PATH = "data"

APACHE_LOG_FILE = "apache.log"

FILTER_URL = ["js", "css", "php", "jsp", "asp", "ico", "*"]
URI_EXTENSIONS = ["pdf", "html", "htm", "docx", "doc", "txt", "js", "css", "asp", "jsp", "php", "ico"]

SEP_1 = "#"
SEP_2 = "/"
SEP_3 = "."
SEP_4 = '-'
SEP_5 = '"'
NEW_LINE_CHAR = '\n'
PLACEHOLDER_1 = " {} |"
PLACEHOLDER_2 = "|"
PLACEHOLDER_3 = "| {} |"
PLACEHOLDER_4 = " | "
PLACEHOLDER_DATA = "{}"
REQUEST_PROTOCOL = "HTTP/1.1"

REPORT = {
    "article_report": {
        "file_name": "article_report.md",
        "header": ["URL", "文章标题", "访问人次", "访问IP数"],
        "segments": 4
    },
    "ip_report": {
        "file_name": "ip_report.md",
        "header": ["IP", "访问次数", "访问文章数"],
        "segments": 3
    },
    "entire_report": {
        "file_name": "entire_report.md",
        "header": ["IP", "URL", "访问次数"],
        "segments": 3
    }
}
package context

import (
	"nhw-log/conf"
	"nhw-log/report"
)

type Context struct {
	Reader  conf.Reader
	LogConf *conf.LogConf
	Report  map[string]report.Report
	Count   int32
}

//	解析一下配置填到上下文中
func ApplyConf(logConf *conf.LogConf, reader conf.Reader) Context {
	ctx := Context{
		LogConf: logConf,
		Reader:  reader,
		Report:  make(map[string]report.Report),
	}
	for i, reportType := range ctx.LogConf.Report.Content {
		content := report.GetReport(reportType)
		if content != nil {
			ctx.Report[reportType] = content
			content.SetTitle(ctx.LogConf.Report.Fileds[i])
		}
	}
	return ctx
}

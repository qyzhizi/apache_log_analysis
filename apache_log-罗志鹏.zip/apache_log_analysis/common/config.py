# -*- coding: utf-8 -*-
import logging
import logging.handlers

# 访问ip-访问时间-访问路径（类型）-协议-返回状态-访问端口
# RE_LOG_LINE = r'(\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}).*?\[(.*?)\].*?' \
#                         r'"([a-z]{1,4}).*(/.*?\.([a-z]{1,5})).*?' \
#                         r'([a-z]{1,5})/.*?".*?(\d{3}).*?(\d+)'
# RE_LOG_LINE_PATTERN = r'(^\d+\.\d+\.\d+\.\d+).*?\[(.*?)\].*?' \
#               r'"([a-z]{1,4}).*?(/.*\.([a-z]{1,5})).*?' \
#               r'([a-z]{1,5})/.*?".*?(\d{3}).*?(\d+)'
RE_LOG_LINE_PATTERN = r'(^\d+\.\d+\.\d+\.\d+).*?' \
                      r'"([a-z]{1,4}).*?(/.*\.([a-z]{1,5})).*?'  # 空格
DEFAULT_TITLE = "This is a default title"

# 日志文件路径
# LOG_FILE = r'C:/Users/qy/Documents/laptop-win-2021/sanfor_2_study/'\
#            'apache_log/data/access_log.txt'
# LOG_FILE = r'C:/Users/qy/Documents/laptop-win-2021/sanfor_2_study'\
#            '/apache_log/data/apache.log'
# LOG_FILE = r'C:/Users/qy/Documents/laptop-win-2021/sanfor_2_study' \
#            '/apache_log/data/apache_2.log'
LOG_FILE = r'C:/Users/qy/Documents/laptop-win-2021/sanfor_2_study/'\
           'apache_log/data/test_log_data.txt'

# 输出文章报表路径
ARTICLE_TABLE_PATH = r'C:/Users/qy/Documents/laptop-win-2021/' \
                     'sanfor_2_study/apache_log/data/article_table.md'
# 输出IP报表的路径
IP_TABLE_PATH = r'C:/Users/qy/Documents/laptop-win-2021/' \
                'sanfor_2_study/apache_log/data/ip_table.md'
# 输出完整报表的路径
WHOLE_TABLE_PATH = r'C:/Users/qy/Documents/laptop-win-2021/' \
                   'sanfor_2_study/apache_log/data/whole_table.md'

# 文章报表的输出头部格式
ARTICLE_TITLE_FORMAT = "| URL  | 文章标题 | 访问人次   | 访问IP数 |\n" \
                       "|----------|----------|------------|----------|"
# 文章报表的输出内容格式
ARTICLE_LINE_FORMAT = "|{url} | {title} | {visit_nums} | {ip_nums} |"

# ip报表的输出头部格式
IP_TITLE_FORMAT = "| IP  | 访问次数 | 访问文章数 |\n" \
                  "|----------|----------|------------|"
# ip报表的输出内容格式
IP_LINE_FORMAT = "|{ip} |{visit_nums} | {article_nums} |"

# 完整报表的输出头部格式
WHOLE_TITLE_FORMAT = "| IP  | URL | 访问次数 |\n" \
                     "|----------|----------|------------|"
# 完整报表的输出内容格式
WHOLE_LINE_FORMAT = "|{ip} |{url} | {visit_nums} |"

# mock时patch的公共路径
# MOCK_PATH = "apache_analyse.app.analyse.provider"

LOG_FILE_NAME = r'C:/Users/qy/Documents/laptop-win-2021/' \
                'sanfor_2_study/apache_log/data/public.log'
LOG_FORMATTER = '%(asctime)s - %(filename)s - %(levelname)s - %(message)s'
ERROR_LOG_FILE_NAME = r'C:/Users/qy/Documents/laptop-win-2021/' \
                      'sanfor_2_study/apache_log/data/error.log'
ERROR_LOG_FORMATTER = "%(asctime)s - %(levelname)s - %(filename)s" \
                      "[:%(lineno)d] - %(message)s"


def get_log():
    """
    返回自定义日志器
    public_log 记录所有日志信息， 格式：日期-级别-信息
    error_log 记录error级别以上的日志信息， 格式：日期-级别-文件[:行号]-信息
    control_handler 输出到控制台  格式：日期-级别-信息
    :return: logging
    """
    logger = logging.getLogger("Apache_Analysis_Log")
    logger.setLevel(level=logging.DEBUG)
    if not logger.handlers:
        # 创建一个handler，用于输出到控制台
        control_handler = logging.StreamHandler()
        control_handler.setLevel(logging.DEBUG)
        control_handler.setFormatter(logging.Formatter(LOG_FORMATTER))

        # 创建一个handler，用于输出到文件
        public_handler = logging.FileHandler(LOG_FILE_NAME)
        public_handler.setFormatter(
            logging.Formatter(LOG_FORMATTER))

        # 创建一个handler，用于输出到error文件
        error_handler = logging.FileHandler(ERROR_LOG_FILE_NAME)
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(logging.Formatter(ERROR_LOG_FORMATTER))

        logger.addHandler(public_handler)
        logger.addHandler(error_handler)
        logger.addHandler(control_handler)
    return logger

from time import time
from apache_analyse.app.analyse.provider import ApacheAnalyse


if __name__ == '__main__':
    begin_time = time()
    end_time = time()
    apache_analyse = ApacheAnalyse()
    print("读取时间：%s" % str(time()-end_time))
    end_time = time()
    apache_analyse.get_article_report()
    print("生成文章报表时间：%s" % str(time() - end_time))
    end_time = time()
    apache_analyse.get_ip_report()
    print("生成ip报表时间：%s" % str(time() - end_time))
    end_time = time()
    apache_analyse.get_complete_report()
    print("生成完整报表时间：%s" % str(time() - end_time))
    end_time = time()
    print("总时间：%s" % str(time() - begin_time))

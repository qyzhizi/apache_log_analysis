# coding=utf-8

from apache_report.common.utils import match_string
from apache_report.common.utils import valid_ip
from apache_report.common.utils import valid_url


def _check_request(req):
    """
    1G数据此函数过滤需要10s以上
    :param req: 请求类型数据
    :return: bool
    """
    if req.ip is None or not valid_ip(req.ip):
        return False
    if req.url is None or not valid_url(req.url):
        return False
    # if not req.check_status:
    #     return False
    return True


class Filter(object):
    # 过滤有效请求
    def __init__(self, suffix):
        """
        :param suffix: 所有符合的后缀列表
        """
        self.suffix = suffix

    def filter_target_page(self, url):
        """过滤所有目标后缀文件"""
        for s in self.suffix:
            if match_string(url, s):
                return False
        return True

    def filter_valid_req(self, req):
        # 简单实现方法是复制
        # TODO 但是如果数据量很大时，内存占用过大，需要设计一个迭代器来完成过滤
        # 过滤没有IP，不满足的后缀等的无效数据
        # if _check_request(req) and self.filter_target_page(req.url):
        #     return True
        if self.filter_target_page(req.url):
            return True
        return False


# coding=utf-8
class ArticleModel(object):
    """保存文章报表数据类型
    示例：| URL  | 文章标题 | 访问人次   | 访问IP数 |
    |------|----------|------------|----------|
    |/coding/miniprj/material.html | 训练素材 | 20 | 4 |
    """
    def __init__(self, url, title, request_people, ip_num):
        self.url = url
        self.title = title
        self.request_people = request_people
        self.ip_num = ip_num

    def to_list(self):
        return [self.url, self.title, self.request_people, self.ip_num]


class IPReportModel(object):
    """保存IP报表数据类型
    示例：
    | IP  |  访问次数 | 访问文章数 |
    |-----|-----------|------------|
    | 200.200.76.130 | 40 | 15 |
    """
    def __init__(self, ip, request_num, article_num):
        self.ip = ip
        self.request_num = request_num
        self.article_num = article_num

    def to_list(self):
        return [self.ip, self.request_num, self.article_num]


class CompleteReportModel(object):
    """保存完整报表数据类型
    示例：
    | IP   | URL |  访问次数 |
    |------|-----|-----------|
    |200.200.76.130 | /coding/miniprj/material.html | 3 |
    |200.200.76.130|/coding/style/%E7%BC%96%E7%A0%81%E9%A3%8E%E6%A0%BC.zip | 1 |
    |177.1.81.42|/designing/tools/image/UML_classes.docx|1|
    """
    def __init__(self, ip, url, request_num):
        self.ip = ip
        self.url = url
        self.request_num = request_num

    def to_list(self):
        return [self.ip, self.url, self.request_num]


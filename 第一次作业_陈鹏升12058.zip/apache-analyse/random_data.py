from multiprocessing import Pool, cpu_count
from time import time
import random
import uuid

DEFAULT_SAVE_PATH = r'E:\python_project\apache-analyse\apache.log'
DEFAULT_METHOD_LIST = ['GET', 'POST', 'HEAD', 'DELETE']
DEFAULT_TYPE_LIST = ['html', 'css', 'js', 'doc', 'png', 'mpg']


def get_format_text(start, end):
    content_list = []
    for _ in range(start, end):
        random_ip = '.'.join([str(random.randint(0, 255)) for _ in range(4)])
        random_uid = uuid.uuid4().hex
        random_method = DEFAULT_METHOD_LIST[random.randint(
            0, len(DEFAULT_METHOD_LIST)-1)]
        random_type = DEFAULT_TYPE_LIST[random.randint(
            0, len(DEFAULT_TYPE_LIST)-1)]
        content = '{ip} - - [16/Feb/2019:11:27:20 +0800] ' \
                  '"{method} /coding/miniprj/{uuid}.{type} ' \
                  'HTTP/1.1" 200 38093'.format(ip=random_ip,
                                               method=random_method,
                                               uuid=random_uid,
                                               type=random_type)
        content_list.append(content)
    return '\n'.join(content_list)


def write_to_file(content):
    with open(DEFAULT_SAVE_PATH, 'a+') as f:
        f.writelines(content)


if __name__ == '__main__':
    # 想要多少条在这改
    data_nums = 1000*1000+1
    default_size = 1000*1000
    begin_time = time()
    if data_nums > default_size:
        pool = Pool()
        workers = 6
        for i in range(workers):
            start_ = data_nums // workers * i
            end_ = data_nums // workers * (i+1)
            # print(start_, end_)
            pool.apply_async(get_format_text, (start_, end_, ),
                             callback=write_to_file)
        pool.close()
        pool.join()
    else:
        write_to_file(get_format_text(0, data_nums))
    print(time() - begin_time)


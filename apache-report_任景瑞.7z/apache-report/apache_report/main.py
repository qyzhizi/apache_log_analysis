# coding=utf-8
import logging
import time

from apache_report.common.utils import set_logger
from apache_report.app import parse_log
from apache_report.app import filter
from apache_report.acquire import acquire_data
from apache_report.common.common_variables import suffix
from apache_report.common.common_variables import manager_dict
from apache_report.common.common_variables import cfg

logger = set_logger(name=__name__, level=logging.DEBUG)


def process_request():
    # TODO 并发完成解析处理
    data = acquire_data.get_data(cfg.get('FILE', 'log_file'))
    req_list = []
    # 此处请求解析和过滤合并
    st = time.time()
    mid = filter.Filter(suffix)
    for d in data:
        # 解析+过滤层 -> 作为输入层到后台的中间层
        req = parse_log.parse_comp_re(d)
        # 过滤请求是否满足要求
        if mid.filter_valid_req(req):
            req_list.append(req)
    return req_list


def report_generate(save_report, req_list):
    for r in save_report:
        manager = manager_dict[r](req_list)
        manager.generate_table()
        manager.save_report(cfg.get('FILE', r + '_file'))


def main():
    logger.info('开始解析apache日志')
    # 解析日志数据
    start = time.time()
    req_list = process_request()
    resolve_time = time.time()
    logger.debug('解析完毕, 用时: %s' % str(resolve_time - start))
    # 后台业务逻辑层处理报表
    save_report = ['article_table', 'ip_table', 'complete_table']
    report_generate(save_report, req_list)
    end = time.time()
    logger.debug('报表生成完毕, 用时: %s' % str(end - resolve_time))


if __name__ == '__main__':
    # input module
    # report_type: 'article_table' 'ip_table' 'complete_table'
    # execute
    main()


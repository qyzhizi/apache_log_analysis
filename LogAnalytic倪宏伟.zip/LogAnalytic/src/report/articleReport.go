package report

import (
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"io"
	"net/http"
	"nhw-log/common"
	"strings"
	"time"
)

type ArticleReportContent struct {
	Title    string
	ReqCount int
	ReqIp    map[string]bool
}

type ArticleReport struct {
	client http.Client
	Report map[string]*ArticleReportContent
	Name   string
	title  []string
}

func (arep *ArticleReport) Finish() {
	for url, content := range arep.Report {
		if strings.Contains(url[len(url)-5:], ".html") || strings.Contains(url[len(url)-4:], ".htm") {
			requestUrl := common.APACHEADDRESS + url
			resp, err := arep.client.Get(requestUrl)
			if err == nil {
				doc, err := goquery.NewDocumentFromReader(resp.Body)
				if err == nil {
					content.Title = doc.Find("head title").First().Text()
				}
			}
		}
	}
}

func (arep *ArticleReport) SetTitle(title []string) {
	arep.title = title
}

func (arep *ArticleReport) GetTitle() []string {
	return arep.title
}

func (arep *ArticleReport) Init() {
	arep.client = http.Client{Timeout: 5 * time.Second}
	arep.Report = make(map[string]*ArticleReportContent)
	arep.Name = "article"
}

func (arep *ArticleReport) Set(url string, ip string) {
	reportContent := arep.Report[url]
	if reportContent != nil {
		reportContent.ReqCount++
		reportContent.ReqIp[ip] = true
	} else {
		title := "default"
		arep.Report[url] = &ArticleReportContent{
			Title:    title,
			ReqCount: 1,
			ReqIp:    map[string]bool{ip: true},
		}
	}
}

//	导出md报表内容
func (arep *ArticleReport) Export(writer io.Writer, exportType string) {

	if exportType == common.MD {
		GenerateMDTitle(writer, arep.title)
		for url, reportContent := range arep.Report {
			fmt.Fprintf(writer, "|%s|%s|%d|%d|\n", url,
				reportContent.Title, reportContent.ReqCount, len(reportContent.ReqIp))
		}
	} else if exportType == common.HTML {
		GenerateHTMLTitle(writer, arep.title)
		for url, reportContent := range arep.Report {
			fmt.Fprintf(writer, "<tr><td>%s</td><td>%s</td><td>%d</td><td>%d</td></tr>\n", url,
				reportContent.Title, reportContent.ReqCount, len(reportContent.ReqIp))
		}
	}

}

func (arep *ArticleReport) Names() string {
	return arep.Name
}

func (arep *ArticleReport) Merge(report Report) {
	amap := report.Values().(map[string]*ArticleReportContent)
	for key, val := range amap {
		if arep.Report[key] == nil {
			arep.Report[key] = val
		} else {
			arep.Report[key].ReqCount += val.ReqCount
			for ip, _ := range val.ReqIp {
				arep.Report[key].ReqIp[ip] = true
			}
		}
	}

}

func (arep *ArticleReport) Values() interface{} {
	return arep.Report
}

import unittest

from apache_report.app.request import get_article_name


class TestGetArticle(unittest.TestCase):
    def test_get_article(self):
        url = '/designing/tools/image/ML_class.htm'
        url2 = '/designing/tools/image/ML_classes.html'

        res = get_article_name(url)
        res2 = get_article_name(url2)
        self.assertEqual(res, '/ML_class')
        self.assertEqual(res2, '/ML_classes')

    def test_get_page_name(self):
        url = '/coding/style/%E7%BC%96%E7%A0%81%E9%A3%8E%E6%A0%BC.zip'
        res = get_article_name(url)
        self.assertEqual(res, '/%E7%BC%96%E7%A0%81%E9%A3%8E%E6%A0%BC.zip')
        url2 = '/designing/tools/image/UML_classes.docx'
        res2 = get_article_name(url2)
        self.assertEqual(res2, '/UML_classes.docx')


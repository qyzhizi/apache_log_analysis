# coding=utf-8
import functools

import pandas as pd

from apache_report.app.reporting import models
from apache_report.storing.files import FileWriter
from apache_report.common.utils import set_logger

logger = set_logger()


def generate_report(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger.info('生成报表数据')
        func(*args, **kwargs)
        logger.info('生成报表数据完成')
    return wrapper


class Manager(object):
    def __init__(self, data):
        self.requests = data
        self.tables = []
        self.cols = []

    def generate_table(self):
        pass

    def save_report(self, filename):
        pass


class ArticleManager(Manager):
    def __init__(self, requests):
        super(ArticleManager, self).__init__(requests)

    @generate_report
    def generate_table(self):
        """业务逻辑：处理统计请求中URL文章访问情况"""
        article_access = dict()
        for r in self.requests:
            # 增加url和对应访问的ip
            if r.url not in article_access:
                article_access[r.url] = [[r.ip], 1, r.title]
            else:
                # 增加url被访问次数
                article_access[r.url][1] += 1
                # 增加没有在访问列表中的ip
                if r.ip not in article_access[r.url][0]:
                    article_access[r.url][0].append(r.ip)
        # 生成存储报表模型所需数据
        for url in article_access:
            article_data = models.ArticleModel(
                url, article_access[url][2], article_access[url][1],
                len(article_access[url][0])
            ).to_list()
            self.tables.append(article_data)

    @generate_report
    def generate_table1(self):
        dd = []
        columns = ['IP', 'URL']
        title_dict = dict()
        for r in self.requests:
            dd.append([r.ip, r.url])
            title_dict[r.url] = r.title
        # 生成请求IP与URL对应表
        df = pd.DataFrame(dd, columns=columns)
        # 按url分组划分结果
        url_table = df.groupby('URL')
        # 获得每个url访问次数
        url_access = list(url_table.count()['IP'])
        url_list = list([i for i, j in url_table])
        # 去除重复数据
        df = df.drop_duplicates()
        # 统计每个url中ip的结果
        url_distinct = df.groupby('URL')
        ip_num = list(url_distinct.count()['IP'])
        for i in range(len(url_list)):
            self.tables.append([url_list[i], title_dict[i],
                                url_access[i], ip_num[i]])

    def save_report(self, filename):
        cols = ['URL', '文章标题', '访问人次', '访问IP数']
        FileWriter.write_file_to_txt(filename, self.tables, cols)


class IPReportManager(Manager):
    def __init__(self, requests):
        super(IPReportManager, self).__init__(requests)

    @generate_report
    def generate_table(self):
        """业务逻辑：处理统计请求中IP访问情况"""
        ip_access = dict()
        for r in self.requests:
            # 增加ip访问的url列表
            if r.ip not in ip_access:
                ip_access[r.ip] = [[r.url], 1]
            else:
                # 增加ip访问次数
                ip_access[r.ip][1] += 1
                # 增加不在ip访问列表的url
                if r.url not in ip_access[r.ip][0]:
                    ip_access[r.ip][0].append(r.url)
        # 生成存储报表模型所需数据
        for ip in ip_access.keys():
            ip_table_data = models.IPReportModel(
                ip, ip_access[ip][1], len(ip_access[ip][0])).to_list()
            self.tables.append(ip_table_data)

    def save_report(self, filename):
        cols = ['IP', '访问次数', '访问文章数']
        FileWriter.write_file_to_txt(filename, self.tables, cols)


class CompleteReportManager(Manager):
    def __init__(self, requests):
        super(CompleteReportManager, self).__init__(requests)

    @generate_report
    def generate_table(self):
        """业务逻辑：处理统计请求中IP与URL访问情况"""
        ip_url = dict.fromkeys([r.ip for r in self.requests], {})
        for r in self.requests:
            # 不在ip访问列表的url设为1
            if r.url not in ip_url[r.ip]:
                ip_url[r.ip][r.url] = 1
            # 已存在列表的url访问次数增加
            else:
                ip_url[r.ip][r.url] += 1
        # 生成存储报表模型所需数据
        for ip in ip_url.keys():
            for url in ip_url[ip]:
                ip_url_data = models.CompleteReportModel(
                    ip, url, ip_url[ip][url]).to_list()
                self.tables.append(ip_url_data)

    def save_report(self, filename):
        cols = ['IP', 'URL', '访问次数']
        FileWriter.write_file_to_txt(filename, self.tables, cols)

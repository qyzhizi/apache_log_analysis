# -*- coding: utf-8 -*-
import os
import multiprocessing
from multiprocessing import Pipe
from functools import reduce

from apache_log.parse.md_handler import MarkdownHandler
from apache_log.parse.exception import CheckFileError
from apache_log.common.const import ENDPOINT
from apache_log.common.const import FILE_FILTER
from apache_log.common.const import TOPIC_FILTER
from apache_log.common.utils import get_log_files
from apache_log.common.utils import get_topic_name
from apache_log.common.utils import check_file
from apache_log.common.utils import read_file
from apache_log.common.utils import parse_file
from apache_log.common.utils import sum_dict


class LogHandler(object):
    u"""
    日志数据处理器
    作用: 解析配置文件信息，生成日志信息对象, 用于生成三个报表中所需要的数据信息
    """

    def __init__(self, filename):
        self.filename = filename
        self.endpoint = ENDPOINT
        self.topic_filter = TOPIC_FILTER
        self.file_filter = FILE_FILTER
        self.ip_data = {}
        self.url_data = {}
        self.log_data = {}
        self.__create_log_data(self.filename)
        self.__create_ip_data()
        self.__create_url_data()
        self.md_hander = MarkdownHandler()

    def create_ip_md(self, filename):
        u"""
        :param filename: 生成ip报表的路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)
        self.md_hander.create_ip_md(self.ip_data, filename)

    def create_url_md(self, filename):
        u"""
        :param filename: 生成url报表的路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)
        self.md_hander.create_url_md(self.url_data, filename)

    def create_log_md(self, filename):
        u"""
        :param filename: 生成完整报表的路径
        :return: None
        """
        if not check_file(filename):
            raise CheckFileError(filename)
        self.md_hander.create_log_md(self.log_data, filename)

    def get_log_data(self):
        u"""
        获取完整报表数据log_data
        :return: log_data
        {
          "(127.0.0.1, /coding/miniprj/material.html)" : 56
          ...
        }
        """
        return self.log_data

    def get_ip_data(self):
        u"""
        获取ip报表数据
        :return: ip_data
        {
          "127.0.0.1" :{
                  "topic_count": 1,
                  "view_count": 3,
                }
          ...
        }
        """
        return self.ip_data

    def get_url_data(self):
        u"""
        获取文章报表数据url_data
        :return: url_data
        {
          "/coding/miniprj/material.html" :{
                  "name": "xyz",
                  "view_count": 3,
                  "ip_count": 7,
                }
          ...
        }
        """
        return self.url_data

    def __create_ip_data(self):
        u"""
        通过log_info构造ip报表的数据对象ip_data
        :return: None
        """
        for k, v in self.log_data.items():
            if k[0] in self.ip_data:
                self.ip_data[k[0]]['view_count'] += v
                if k[1].endswith(self.topic_filter):
                    self.ip_data[k[0]]['topic_count'] += 1
            else:
                if k[1].endswith(self.topic_filter):
                    topic_count = 1
                else:
                    topic_count = 0
                ip_info = {'view_count': v, 'topic_count': topic_count}
                self.ip_data[k[0]] = ip_info

    def __create_url_data(self):
        u"""
        通过log_info构造文章报表的数据对象url_data
        :return: None
        """
        ip_list = list()
        for k, v in self.log_data.items():
            if not k[1].endswith(self.topic_filter):
                continue
            if k[1] in self.url_data:
                self.url_data[k[1]]['view_count'] += v
                if k[0] not in ip_list:
                    ip_list.append(k)
                    self.url_data[k[1]]['ip_count'] += 1
            else:
                topic_name = get_topic_name(k[1], self.endpoint)
                # 获取不到则忽略
                if not topic_name:
                    return
                url_info = {'name': topic_name, 'view_count': v, 'ip_count': 1}
                self.url_data[k[1]] = url_info

    def __create_log_data(self, filename):
        u"""
        :param filename: 需要解析的log日志文件
        :return: None
        """
        # 获取日志文件路径
        files = list()
        if os.path.isdir(filename):
            files = get_log_files(filename)
        else:
            files.append(filename)

        # 使用多进程以及管道读写结果,提升读效率
        log_list = []
        pool = multiprocessing.Pool(processes=len(files) + 1)
        parent_conn, child_conn = Pipe()
        for file in files:
            data = read_file(file)
            pool.apply_async(parse_file, (child_conn, data,))
        pool.close()
        for i in range(len(files)):
            log_list.append(parent_conn.recv())
        pool.join()

        # 拼接结果
        self.log_data = reduce(sum_dict, log_list)

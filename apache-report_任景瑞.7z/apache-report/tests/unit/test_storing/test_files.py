import unittest
import mock

from apache_report import exception

from apache_report.storing.files import FileWriter


class TestFileWriter(unittest.TestCase):
    def test_write(self):
        FileWriter.write_file_to_txt('123.txt', 'abc', ['1'])
        with open('123.txt', 'r') as f:
            actual = []
            for i in f.readlines():
                actual.append(i.strip('\n'))
            self.assertEqual('\n'.join(actual),
                             '| 1 |\n| -: |\n| a |\n| b |\n| c |')

    @mock.patch('storing.files.markdown_format')
    def test_write_with_no_head(self, mock_markdown_format):
        mock_markdown_format.return_value = ['test\n']
        self.assertRaises(exception.FileStreamException,
                          FileWriter.write_file_to_txt,
                          '', '', [])
        FileWriter.write_file_to_txt('test_log.txt', 'abc', ['1'])
        with open('test_log.txt', 'r') as f:
            self.assertEqual(f.readlines(),
                             ['test\n'])

    @mock.patch('storing.files.markdown_format')
    def test_write_file(self, mock_formatting_markdown):
        mock_formatting_markdown.return_value = ['test_head\n']
        self.assertRaises(exception.FileStreamException,
                          FileWriter.write_file_to_txt_with_head,
                          '', '', [])
        FileWriter.write_file_to_txt_with_head('test_log_head.txt', '', [])
        with open('test_log_head.txt', 'r') as f:
            self.assertEqual(f.readlines(), ['test_head\n'])

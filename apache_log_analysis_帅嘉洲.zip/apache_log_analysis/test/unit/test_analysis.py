import os
import shutil
import unittest

from apache_log_analysis.app import report_form_basic
from apache_log_analysis.app.analyst import LogAnalysis
from apache_log_analysis.app.webviewer import TitleGetter
from apache_log_analysis.common import exceptions as exc

# 路径，为同级目录
FILES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "files")
LOG_FILE_NAME = "apache.log"
# 样例log的有效项
LOG_EFFECTIVE_NUM = 9
# 考察的url和对应数据
MATERIAL_URL = "/coding/miniprj/material.html"
MATERIAL_URL_TIMES = 3
MATERIAL_URL_IP_NUM = 2
# 考察的ip和对应数据
MATERIAL_IP = "200.200.76.130"
MATERIAL_IP_TIMES = 4
MATERIAL_IP_ARTICLE_NUM = 1


class TestAnalysis(unittest.TestCase):
    def test_log_line_wrong(self):
        """日志数据错误"""
        log_line = '177.1.81.42 - - [16/Feb/2019:11:28:54 +0800] "' \
                   'GET /designing/tools/image/UML '
        self.assertRaises(exc.NoSuffixException,
                          LogAnalysis("")._analysis_log_line,
                          log_line)
        log_line = '::1 - - [16/Feb/2019:11:27:29 +0800] "' \
                   'OPTIONS * HTTP/1.0" 200 -'
        self.assertRaises(exc.NoIpOrUrlException,
                          LogAnalysis("")._analysis_log_line,
                          log_line)

    def test_get_title_fall(self):
        """获取标题失败"""
        self.assertEqual(TitleGetter().get_article_title(
            "/coding/miniprj/material.html"
        ), TitleGetter.CAN_NOT_REACH)

    def test_analysis_log_dir(self):
        """分析报表文件夹，判断过滤后剩下的日志项数量是否符合预期"""
        analysis = LogAnalysis(FILES_DIR)
        self.assertEqual(
            len(analysis._analysis_log_dir()),
            LOG_EFFECTIVE_NUM,
        )

    def test_analysis_log_file(self):
        """分析报表文件，判断过滤后剩下的日志项数量是否符合预期"""
        analysis = LogAnalysis(FILES_DIR)
        self.assertEqual(
            len(analysis._analysis_log_file(
                os.path.join(FILES_DIR, LOG_FILE_NAME))),
            LOG_EFFECTIVE_NUM,
        )

    def test_article_report_form(self):
        """文章日志分析数据是否正确"""
        # 获取log分析的文件数据
        analysis = LogAnalysis(FILES_DIR)
        log_data = analysis._analysis_log_dir()

        # 实例化报表并解析数据
        report_form = report_form_basic.ArticleReportForm(FILES_DIR)
        report_form.report_form_statistics(log_data)
        # report_form.report_form_data()是生成器
        # [URL, 文章标题, 访问人次, 访问IP数]
        for item in report_form.report_form_data():
            if item[0] == MATERIAL_URL:
                self.assertEqual(int(item[2]), MATERIAL_URL_TIMES)
                self.assertEqual(int(item[3]), MATERIAL_URL_IP_NUM)
                break

    def test_ip_report_form(self):
        """ip日志分析数据是否正确"""
        # 获取log分析的文件数据
        analysis = LogAnalysis(FILES_DIR)
        log_data = analysis._analysis_log_dir()

        # 实例化报表并解析数据
        report_form = report_form_basic.IPReportForm(FILES_DIR)
        report_form.report_form_statistics(log_data)
        # report_form.report_form_data()是生成器
        # [IP, 访问次数, 访问文章数]
        for item in report_form.report_form_data():
            if item[0] == MATERIAL_IP:
                self.assertEqual(int(item[1]), MATERIAL_IP_TIMES)
                self.assertEqual(int(item[2]), MATERIAL_IP_ARTICLE_NUM)
                break

    def test_complete_report_form(self):
        """完整日志分析数据是否正确"""
        # 获取log分析的文件数据
        analysis = LogAnalysis(FILES_DIR)
        log_data = analysis._analysis_log_dir()

        # 实例化报表并解析数据
        report_form = report_form_basic.CompleteReportForm(FILES_DIR)
        report_form.report_form_statistics(log_data)
        # report_form.report_form_data()是生成器
        # [IP, URL, 访问次数]
        for item in report_form.report_form_data():
            if item[0] == MATERIAL_IP:
                if item[1] == MATERIAL_URL:
                    self.assertEqual(int(item[2]), MATERIAL_URL_IP_NUM)
                    break

    def test_generate_report_form(self):
        """创建报表成功"""
        md_dir = os.path.join(os.path.dirname(FILES_DIR), "md")
        # 先删除md文件夹
        if os.path.exists(md_dir):
            shutil.rmtree(md_dir)

        analysis = LogAnalysis(FILES_DIR)
        analysis.generate_report_form()

        # 生成了正确数量的报表
        self.assertEqual(
            len(os.listdir(md_dir)),
            len(report_form_basic.ReportFormBase.__subclasses__())
        )


if __name__ == '__main__':
    unittest.main()

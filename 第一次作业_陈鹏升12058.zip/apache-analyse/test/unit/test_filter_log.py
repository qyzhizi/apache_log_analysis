# -*- coding: utf-8 -*-

import unittest

from apache_analyse.common.common import filter_log
from apache_analyse.common.common import MAX_DIRECT_FILTER_SIZE


class TestFilterLog(unittest.TestCase):
    u"""apache日志过滤测试类."""

    mock_log_list = ['250.14.14.53 - - [16/Feb/2019:11:27:20 +0800] '
                     '"DELETE /coding/miniprj/df94b17e38fa4b1c81d136fa20c'
                     '93aa2.css HTTP/1.1" 200 38093\n',
                     '183.107.29.150 - - [16/Feb/2019:11:27:20 +0800] '
                     '"DELETE /coding/miniprj/50879b6444394207a571f3195'
                     '64c959c.css HTTP/1.1" 200 38093\n',
                     '34.46.211.235 - - [16/Feb/2019:11:27:20 +0800] '
                     '"DELETE /coding/miniprj/e4cb38494ec941fc80babbb2f4'
                     '6216cc.js HTTP/1.1" 200 38093\n',
                     '71.193.37.100 - - [16/Feb/2019:11:27:20 +0800] '
                     '"POST /coding/miniprj/0808e90751194e79b40701f674400'
                     '885.doc HTTP/1.1" 200 38093\n',
                     '114.161.217.96 - - [16/Feb/2019:11:27:20 +0800] '
                     '"HEAD /coding/miniprj/fccad59a91564fd09154591c39f18'
                     '827.js HTTP/1.1" 200 38093\n']

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_filter_log(self):
        mock_filter_result = [{'ip': '71.193.37.100', 'method': '"POST',
                               'url': '/coding/miniprj/0808e90751194e79b40701'
                                      'f674400885.doc', 'type': 'doc',
                               'title': '0808e90751194e79b40701f674400885',
                               'status_code': '200'}]

        result_list = filter_log(self.mock_log_list)

        for mock_log_filter, log_filter in zip(mock_filter_result,
                                               result_list):
            self.assertDictEqual(mock_log_filter, log_filter)

        # pool
        mock_filter_result = mock_filter_result * (MAX_DIRECT_FILTER_SIZE+1)
        result_list = filter_log(self.mock_log_list *
                                 (MAX_DIRECT_FILTER_SIZE+1))
        for mock_log_filter, log_filter in zip(mock_filter_result,
                                               result_list):
            self.assertDictEqual(mock_log_filter, log_filter)


if __name__ == '__main__':
    unittest.main()


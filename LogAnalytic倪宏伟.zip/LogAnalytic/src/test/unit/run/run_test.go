package test

import (
	"nhw-log/analytic"
	"nhw-log/conf"
	"nhw-log/context"
	"nhw-log/report"
	"nhw-log/web"
	"testing"
)

func TestRun(t *testing.T) {
	readConf := conf.ReadConf()
	reader := conf.LogRead(readConf)
	context := context.ApplyConf(readConf, reader)
	// 分析日志并输出结果
	analytic.Analyticlog(context)
	report.PrintResult(context.LogConf.OutPutDir,
		context.Report, context.LogConf.Report.Content)
	// 启动web服务
	web.RunWebServer(context.LogConf.HttpAddress, context.Report)
	if len(context.Report) != len(context.LogConf.Report.Content) {
		t.Fatal("错误的输出")
	}
}

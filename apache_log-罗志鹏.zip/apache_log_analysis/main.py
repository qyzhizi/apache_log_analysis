# -*- coding: utf-8 -*-
from time import time

from apache_log_analysis.common.config import RE_LOG_LINE_PATTERN
from apache_log_analysis.common.config import LOG_FILE
from apache_log_analysis.common.config import ARTICLE_TABLE_PATH
from apache_log_analysis.common.config import IP_TABLE_PATH
from apache_log_analysis.common.config import WHOLE_TABLE_PATH
from apache_log_analysis.app.log_analysis import LogAnalysis
from apache_log_analysis.common.config import get_log

logger = get_log()

if __name__ == '__main__':
    start_time = time()
    logger.debug("=========================Start===========================")
    log_analysis = LogAnalysis(LOG_FILE, RE_LOG_LINE_PATTERN)

    begin_time = time()
    log_analysis.article_report(ARTICLE_TABLE_PATH)
    logger.debug("生成文章报表时间：%s" % str(time() - begin_time))

    begin_time = time()
    log_analysis.ip_report(IP_TABLE_PATH)
    logger.debug("生成ip报表时间：%s" % str(time() - begin_time))

    begin_time = time()
    log_analysis.whole_report(WHOLE_TABLE_PATH)
    logger.debug("生成完整报表时间：%s" % str(time() - begin_time))

    logger.debug("=========================End===========================")
    logger.debug("全部时间：%s" % str(time() - start_time))



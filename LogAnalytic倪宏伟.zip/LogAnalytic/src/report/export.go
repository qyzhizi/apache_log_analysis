package report

import (
	"fmt"
	"io"
	"log"
	"nhw-log/common"
	"os"
	"path/filepath"
)

func GenerateMDTitle(writer io.Writer, title []string) {
	for i := 0; i < len(title); i++ {
		fmt.Fprintf(writer, "|%s", title[i])
		if i == len(title)-1 {
			fmt.Fprintf(writer, "|")
		}
	}
	fmt.Fprintln(writer)
	for i := 0; i < len(title); i++ {
		fmt.Fprintf(writer, "|-----")
		if i == len(title)-1 {
			fmt.Fprintf(writer, "|")
		}
	}
	fmt.Fprintln(writer)
}

func GenerateHTMLTitle(writer io.Writer, title []string) {
	fmt.Fprintln(writer, "<table border=\"1\">")
	fmt.Fprintln(writer, "<tr>")
	for i := 0; i < len(title); i++ {
		fmt.Fprintf(writer, "<td>%s</td>", title[i])
	}
	fmt.Fprintln(writer, "</tr>")
}

func PrintResult(dir string, reports map[string]Report, exportReportStyle []string) {
	if dir == "" {
		dir = "C:\\mydownload\\workspace\\sangfor_test\\"
	}
	for _, style := range exportReportStyle {
		logFilePath := filepath.Join(dir, style)
		logFilePath += ".md"
		file, err := os.OpenFile(logFilePath, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0777)
		if err != nil {
			log.Fatal("open file error ", filepath.Join(dir, style))

		}
		reports[style].Export(file, common.MD)
	}

}

package common

const IP = "ip"
const ARTICLE = "article"
const ALL = "all"
const MD = "md"
const HTML = "HTML"
const APACHEADDRESS = "http://200.200.1.35"
const SPLIT = "split"
const REGULAR = "regular"

package analytic

import (
	"bufio"
	"bytes"
	"io"
	"log"
	"nhw-log/common"
	"nhw-log/utils"
	"strings"
	"sync/atomic"
)

//正则提取

// SingleLogAnalytic 单协程模型
func SingleLogAnalytic(tdata *ThreadLocalData) {
	var url, ipaddr string
	reader := bufio.NewReader(bytes.NewReader(tdata.LogData))
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			} else {
				log.Fatal("analytic failed")
			}
		}
		atomic.AddInt32(&tdata.count, 1)
		if tdata.mode == common.SPLIT {
			url = utils.GetUrlBySplit(line)
			ipaddr = utils.GetIPBySplit(line)
		}else if tdata.mode == common.REGULAR {
			url = utils.GetURLByRegular(line)
			ipaddr = utils.GetIPByRegular(line)
		}
		if ipaddr == "" {
			continue
		}
		if url == "" || url == "*" || strings.Contains(url[len(url)-5:], ".css") ||
			strings.Contains(url[len(url)-5:], ".js") || strings.Contains(url[len(url)-5:], ".ico") {
			continue
		}
		for _, report := range tdata.Reports {
			report.Set(url, ipaddr)
		}

	}
}

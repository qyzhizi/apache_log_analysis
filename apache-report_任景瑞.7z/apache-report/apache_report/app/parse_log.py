# coding=utf-8
import re

from apache_report.app.request import RequestStore
from apache_report.app.request import get_article_name


class ApacheParser(object):
    def __init__(self):
        pass

    def serializing_method(self):
        pass

    def deserializing_method(self):
        pass


def core_parse_opt(request_log):
    """ 接收 apache http 请求数据字符串，转化为请求类型格式
    示例:
        200.200.76.130 - - [16/Feb/2019:11:27:20 +0800]
        "GET /coding/miniprj/material.html HTTP/1.1" 200 38093
    :param request_log: 一条apache请求日志字符串
    :return: req: Request() 请求解析结果
    """
    # 理想情况下符合标准的数据解析
    req = request_log.split(' ')
    ip, status = req[0], req[8]
    time = ''.join([req[3][1:], ' ', req[4][:-1]])
    method = req[5][1:]
    url = req[6]
    title = get_article_name(url)
    req = RequestStore(ip, time, method, url, status, title)
    return req


def parse_comp_re(request_log):
    # 完整匹配
    pattern = r'(?P<ip>.*) - - (?P<time>.*) \"(?P<method>\S+) ' \
              r'(?P<url>.*) [HTTP].*\" (?P<status>\d+) (?P<delay>.*)'
    re.compile(pattern=pattern)
    res = re.match(pattern, request_log)
    ip = res.group('ip')
    url = res.group('url')
    method = res.group('method')
    time = res.group('time')
    status = res.group('status')

    # match ip
    # ip_match = r'\d+\.{3}\d+$'
    # # match url
    # url_match = r'/([a-zA-Z0-9]).*\.$'
    # method_list = r'[GET]|[POST]|[PUT]|[HEAD]'
    # ip = re.search(ip_match, request_log).group()
    # url = re.search(url_match, request_log).group()
    # method = re.search(method_list, request_log).group()

    return RequestStore(ip=ip, url=url,
                        method=method, log_time=time,
                        status=status)

# TODO 解析扩展，提取更多信息

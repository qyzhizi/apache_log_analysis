import unittest
import logging

from apache_report.common.utils import set_logger
from apache_report.common.utils import match_string
from apache_report.common.utils import valid_ip
from apache_report.common.utils import valid_url


class TestSetLogger(unittest.TestCase):
    def test_set_log(self):
        logger = set_logger()
        self.assertIs(type(logger), logging.Logger)
        logger.info('123')

    def test_set_log_level(self):
        logger = set_logger(level=logging.INFO)
        self.assertEqual(logger.level, logging.INFO)


class TestMatchString(unittest.TestCase):
    def test_matched(self):
        self.assertTrue(match_string('/coding/miniprj/material.html', '.html'))
        self.assertTrue(match_string('/coding/miniprj/material.html', 'html'))

    def test_not_match(self):
        self.assertFalse(match_string('/coding/gitbook/search.cs', '.js'))
        self.assertFalse(match_string('/coding/gitbook/search.cs', 'js'))
        self.assertFalse(match_string('/coding/js/search.css', 'js'))
        self.assertFalse(match_string('/coding/js/search.csjs', '.js'))


class TestValidUrl(unittest.TestCase):
    def test_valid_url(self):
        self.assertTrue(valid_url('/coding/gitbook/gitbook-ps/search.cs'))
        self.assertTrue(valid_url('/gin-search-plus/jquery.mark.min.js'))
        self.assertTrue(valid_url('/abc.js'))

    def test_not_valid_url(self):
        self.assertFalse(valid_url('*'))
        self.assertFalse(valid_url('abc'))
        self.assertFalse(valid_url('//'))
        self.assertFalse(valid_url('\\A'))
        self.assertFalse(valid_url('gin-search-plus/jquery.mark.min.js'))


class TestValidIp(unittest.TestCase):
    def test_valid_ip(self):
        self.assertTrue(valid_ip('1.1.1.1'))
        self.assertTrue(valid_ip('0.0.0.0'))
        self.assertTrue(valid_ip('255.255.255.255'))
        self.assertTrue(valid_ip('133.1.254.123'))

    def test_not_valid_ip(self):
        self.assertFalse(valid_ip('255.255.255.256'))
        self.assertFalse(valid_ip('255.255.-1.255'))
        self.assertFalse(valid_ip('0.0.1'))
        self.assertFalse(valid_ip('255.255.255.2.2'))


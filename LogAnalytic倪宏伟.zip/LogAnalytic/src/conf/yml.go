package conf

type LogConf struct {
	Core        int    `yaml:"core"`
	OutPutDir   string `yaml:"outPutDir"`
	HttpAddress string `yaml:"httpAddress"`
	Resource    struct {
		Urls  []string `yaml:"urls"`
		Paths []string `yaml:"paths"`
	}
	ParserMode string `default:"spilt" yaml:"parserMode"`
	Report     struct {
		Content []string   `yaml:"content"`
		Fileds  [][]string `yaml:"fileds"`
	}
}

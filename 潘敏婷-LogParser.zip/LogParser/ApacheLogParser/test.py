# -*- coding:utf-8 -*-
import time

from ApacheLogParser.common import common
from ApacheLogParser.parser.parser import ApacheLogParser

#
# def gen_markdown_table_2d(table_header, records):
#     """
#     传入表头和对应的[[]]数据，输出对应的markdown报表
#     :param table_header:
#     :param records:
#     :return:
#     """
#
#     rows, cols = len(records), len(records[0])
#     lines = []
#
#     # 表头部分
#     lines += [common.PLACEHOLDER_3.format(common.PLACEHOLDER_2.join(table_header))]
#
#     # 分割线
#     tmp = common.PLACEHOLDER_2
#     for i in range(cols):
#         line = common.PLACEHOLDER_1 .format(common.PLACEHOLDER_DATA .format(common.SEP_4 * len(table_header[i])))
#         tmp = ''.join([tmp, line])
#     lines += [tmp]
#
#     # 数据部分
#     for record in records:
#         d = list(map(str, record))
#         lines += [common.PLACEHOLDER_3.format(common.PLACEHOLDER_4.join(d))]
#
#     table = common.NEW_LINE_CHAR.join(lines)
#     return table
#
#
# def table_article_report():
#     cols_name = ["URL", "文章标题", "访问人次", "访问IP数"]
#     data = ApacheLogParser().gen_article_report()
#     table = gen_markdown_table_2d(cols_name, data)
#     return table
#
#
# def table_ip_report():
#     cols_name = ["IP", "访问次数", "访问文章数"]
#     data = ApacheLogParser().gen_ip_report()
#     table = gen_markdown_table_2d(cols_name, data)
#     return table
#
#
# def table_entire_report():
#     cols_name = ["IP", "URL", "访问次数"]
#     data = ApacheLogParser().gen_entire_report()
#     table = gen_markdown_table_2d(cols_name, data)
#     return table

# if __name__ == '__main__':
#     start = time.time()
#     Parser = ApacheLogParser()
#     f = open("log.txt", "w")
#     print("<<<<<<<<<<文章报表>>>>>>>>>>", file=f)
#     print(Parser.gen_article_report(), file=f)
#     print("\n<<<<<<<<<<IP报表>>>>>>>>>>", file=f)
#     print(Parser.gen_ip_report(), file=f)
#     print("\n<<<<<<<<<<完整报表>>>>>>>>>>", file=f)
#     print(Parser.gen_entire_report(), file=f)
#     f.close()
#     print(time.time() - start)


if __name__ == '__main__':
    start = time.time()
    Parser = ApacheLogParser(common.APACHE_LOG_FILE)
    Parser.gen_article_report()
    Parser.gen_ip_report()
    Parser.gen_entire_report()
    print(time.time() - start)

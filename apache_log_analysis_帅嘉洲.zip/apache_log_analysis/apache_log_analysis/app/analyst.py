import datetime
import multiprocessing
import os
import re

from apache_log_analysis.app import report_form_basic
from apache_log_analysis.common import exceptions as exc
from apache_log_analysis.common.logger import Logger

# 过滤的文件后缀名
ABANDON_SUFFIX = ["js", "css"]
# 日志文件后缀
ACCEPT_SUFFIX = ".log"
# 项目运行日志
logger = Logger().get_logger()


class LogAnalysis(object):

    def __init__(self, log_dir):
        """

        :param log_dir: 日志路径
        """
        self.log_dir = log_dir

    def _analysis_log_dir(self):
        """解析日志文件夹下的所有日志

        :return: log_data 解析完日志后的数据
        """
        # 获取文件夹下的所有日志，进行多进程处理
        def file_list():
            for root, dirs, files in os.walk(self.log_dir):
                for f in files:
                    if f.endswith(ACCEPT_SUFFIX):
                        yield os.path.join(root, f)

        # 开cpu核数个进程
        pool = multiprocessing.Pool(processes=multiprocessing.cpu_count())
        # _analysis_log_file需要传入路径来找到文件
        log_data_apart = pool.map(self._analysis_log_file, file_list())
        pool.close()
        pool.join()

        # log_data_apart是二维列表，将其转为一维
        # 这样设计保证读文件夹和读单个文件返回一样的数据
        log_data = [item for list_item in log_data_apart for item in list_item]

        return log_data

    def _analysis_log_file(self, log_file):
        """解析单个日志文件

        :param log_file: 日志文件
        :return:
        """
        # 中间数据，日志解析的输出，报表生成的输入
        log_data_file = []

        with open(log_file, "r", encoding="utf-8") as f:
            for log_line in f:
                try:
                    ip_and_url = self._analysis_log_line(log_line)
                    # 如果存在则添加
                    if ip_and_url:
                        log_data_file.append(ip_and_url)
                except exc.NoSuffixException as e:
                    # log_line末尾是\n，自带换行
                    logger.error(log_line + str(e))
                except exc.NoIpOrUrlException as e:
                    logger.error(log_line + str(e))

        return log_data_file

    def _analysis_log_line(self, log_line):
        """分析日志的一行数据，滤除对css,js等文件的访问，返回访问IP、URL和文件类型
        文件类型使得文章报表遍历数据不用再解析是不是htm/html

        :param log_line: 日志的一行数据
        :return: 该行日志的访问IP、访问URL和文件类型
        """
        # 获取ip和url
        ip_pattern = "(\\d{1,3}\\.){3}\\d{1,3}"
        url_pattern = " /.*? "
        try:
            ip = re.search(ip_pattern, log_line).group()
            url = re.search(url_pattern, log_line).group().strip()
        except AttributeError:
            raise exc.NoIpOrUrlException()

        # 去除路径的查询条件，暴露真正的路径
        only_route = url.rsplit("?", 1)[0]
        file_name_list = only_route.rsplit(".", 1)
        # 判断确实有后缀
        if len(file_name_list) > 1:
            file_type = file_name_list[-1]
            # js、css滤除
            if file_type not in ABANDON_SUFFIX:
                return {
                    "ip": ip,
                    "url": url,
                    "file_type": file_type,
                }
        else:
            raise exc.NoSuffixException()

    def _do_report(self, log_data):
        """依据日志解析数据生成报表

        :param log_data: 日志解析数据
        :return: 无
        """
        # 生成报表实例用于解析数据
        def report_form_list():
            for form in report_form_basic.ReportFormBase.__subclasses__():
                yield form(self.log_dir)

        # 进行处理并生成报表
        for report_form in report_form_list():
            report_form.report_form_statistics(log_data)
            report_form.report_form_output()

    def generate_report_form(self):
        """读取路径下的日志并输出报表

        暴露的接口
        :return: 无
        """
        log_data = self._analysis_log_dir()
        self._do_report(log_data)


if __name__ == "__main__":
    start = datetime.datetime.now()
    # 项目只负责解析日志，日志路径和项目没关系，所以用绝对路径
    log_dir = \
        "C:/Users/asus/Desktop/入职/apache_log_analysis/" \
        "apache_log_analysis/files/logs"
    analysis = LogAnalysis(log_dir)
    analysis.generate_report_form()

    end = datetime.datetime.now()
    logger.debug("Analyst time: %s" % (end - start))

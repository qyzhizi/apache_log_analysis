# coding=utf-8
"""
自动生成数据文件
"""
import random
import datetime

import exception


def ranstr(num):
    """生成随机字符串"""
    s = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%'

    rs = ''
    for i in range(num):
        rs += random.choice(s)

    return rs


def generate_host_ip():
    """生成随机IP地址"""
    with open('host_ip.txt', 'w') as wf:
        for i in range(1101):
            # 获取4个[0-255]的随机数
            ip = [str(random.randint(0, 255)), str(random.randint(0, 255)),
                  str(random.randint(0, 255)), str(random.randint(0, 255))]
            ip_host = '.'.join(ip) + '\n'
            wf.write(ip_host)


def generate_url():
    """生成随机URL地址"""
    with open('test_url.txt', 'w') as wf:
        for i in range(11010):
            split_sharp = random.randint(1, 6)
            str_list = [' ']
            # 使用'/'拼接字符串生成url
            for i in range(split_sharp):
                x = ranstr(random.randint(3, 10))
                str_list.append(x)
            url = '/'.join(str_list)
            method = ['GET', 'POST', 'PUT']
            # 可选择后缀列表
            suffix = ['js', 'css', 'html', 'htm', 'ico', 'doc', 'docx', 'mpg']
            num = random.randint(0, len(suffix) - 1)
            url = ''.join(["\"", method[random.randint(0, 2)],
                           url, '.',
                           suffix[num],
                           ' HTTP/1.1', "\""])
            wf.write(url + '\n')


def random_log(ip_list, url_list):
    """随机生成apache日志
    :param: ip_list:  可选ip列表
    :param: url_list: 可选url列表
    :return: str: 一条apache日志记录
    """
    # 获取ip地址，去除末尾换行符
    ip_host = ip_list[random.randint(0, len(ip_list) - 1)].strip()
    # 获取当前时间
    cur_time = datetime.datetime.now().strftime('%d/%m/%y:%H:%M:%S +0800')

    url = url_list[random.randint(0, len(url_list) - 1)].strip()
    status = '200'
    delay = str(random.randint(1, 10000))
    return ' '.join([ip_host, '-', '-', '[' + cur_time + ']',
                     url, status, delay])


def generator_apache_log():
    """随机生成一千万条apache日志记录"""
    try:
        with open('test_url.txt', 'r') as rf:
            url_list = rf.readlines()
    except exception.FileNotFoundException:
        raise EOFError
    try:
        with open('host_ip.txt', 'r') as rf:
            ip_list = rf.readlines()
    except exception.FileNotFoundException:
        raise EOFError
    with open('apache_test_log.txt', 'w') as wf:
        for i in range(int(1e7)):
            rlog = ''.join([random_log(ip_list, url_list), '\n'])
            wf.write(rlog)


generator_apache_log()

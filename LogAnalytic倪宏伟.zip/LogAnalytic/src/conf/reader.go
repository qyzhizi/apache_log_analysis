package conf

import (
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
)

type Reader interface {
	readConf() bool
	NextRead() ([]byte, bool)
}

func LogRead(conf *LogConf) Reader {
	var reader Reader
	if conf.Resource.Urls != nil {
		reader = &HTTPReader{
			urls: conf.Resource.Urls,
		}
	} else if conf.Resource.Paths != nil {
		reader = &LocalReader{
			filePaths: conf.Resource.Paths,
		}
	} else {
		log.Fatal("not read resource")
	}
	ok := reader.readConf()
	if ok != true {
		log.Fatal("read log is error ")
	}
	return reader
}

type HTTPReader struct {
	urls    []string
	readers []io.Reader
	offset  int
}

func (h *HTTPReader) readConf() bool {
	success := 0
	h.readers = make([]io.Reader, len(h.urls))
	for i := 0; i < len(h.urls); i++ {
		resp, err := http.Get(h.urls[i])
		if err != nil {
			continue
		}
		success++
		h.readers[i] = resp.Body
	}
	if success == 0 {
		return false
	}
	return true
}

func (h *HTTPReader) NextRead() ([]byte, bool) {
	if h.offset >= len(h.urls) {
		return nil, false
	}
	logData, err := ioutil.ReadAll(h.readers[h.offset])
	h.offset++
	if err == nil {
		return nil, false
	}
	return logData, true
}

type LocalReader struct {
	filePaths []string
	offset    int
	readers   []io.Reader
}

func (l *LocalReader) readConf() bool {
	l.readers = make([]io.Reader, len(l.filePaths))
	for i := 0; i < len(l.filePaths); i++ {
		file, err := os.OpenFile(l.filePaths[i], os.O_RDWR, 0777)
		if err != nil {
			continue
		}
		l.readers[i] = file
	}
	return true
}

func (l *LocalReader) NextRead() ([]byte, bool) {
	if l.offset >= len(l.filePaths) {
		return nil, false
	}
	logData, err := ioutil.ReadAll(l.readers[l.offset])
	l.offset++
	if err != nil {
		return nil, false
	}
	return logData, true
}

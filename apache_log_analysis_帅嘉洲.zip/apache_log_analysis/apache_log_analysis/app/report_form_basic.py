import os
from urllib import parse as urllib_parse

from apache_log_analysis.app.webviewer import TitleGetter

# 文章后缀
ARTICLE_SUFFIX = ["htm", "html"]
# 协程数量
COROUTINE_NUM = 5


class ReportFormBase(object):
    """报表基类
    report_form_output所有子类相同，所以子类都没重写
    """
    # 报表名
    form_name = ""
    # 报表表头
    form_head = []

    def __init__(self, file_dir):
        # 从log解析来的数据
        self.log_data = {}
        # 报表路径
        self.file_dir = file_dir

    def report_form_statistics(self, log_list):
        """解读日志信息

        :param log_list: 日志解读数据，列表，每项有ip、url、file_type三个键
        :return: 无
        """
        pass

    def report_form_data(self):
        """做一定处理后形成最终的报表数据

        :return: 报表数据
        """
        yield []

    def report_form_output(self):
        """生成报表

        :return: 无
        """
        # 生成markdown文件夹
        md_path = os.path.join(os.path.dirname(self.file_dir), "md")
        if not os.path.exists(md_path):
            os.mkdir(md_path)
        # 生成对应的markdown文件
        md_file = os.path.join(md_path, self.form_name+".md")
        with open(md_file, "w", encoding='utf-8') as f:
            # 表头
            f.write("|" + "|".join(self.form_head) + "|\n")
            f.write("|" + "----|"*len(self.form_head) + "\n")
            # 内容，需要将int转为str
            for row in self.report_form_data():
                f.write("|" + "|".join(row) + "|\n")


class ArticleReportForm(ReportFormBase):
    form_name = "文章报表"
    form_head = ["URL", "文章标题", "访问人次", "访问IP数"]

    def report_form_statistics(self, log_list):
        """解读日志信息

        生成{url:{"file_type": xxx,"times": xxx,"ip_list": []}}
        :param log_list: 日志解读数据，列表，每项有ip、url、file_type三个键
        :return: 无
        """
        # {url:[]}，将ip放入列表，从而判断该ip是否被记录过
        url_and_ip_cache = {}
        # self.log_data是{url:{"file_type": str,"times": int,"ip_num": int}}

        for log_line in log_list:
            # 如果url已被记录，则访问人次+1，并判断访问IP是否有重复
            if log_line["url"] in url_and_ip_cache:
                self.log_data[log_line["url"]]["times"] += 1
                if log_line["ip"] not in url_and_ip_cache[log_line["url"]]:
                    url_and_ip_cache[log_line["url"]].append(log_line["ip"])
                    self.log_data[log_line["url"]]["ip_num"] += 1                  
            # 如果url未被记录，则创建该记录
            else:
                url_and_ip_cache[log_line["url"]] = [log_line["ip"]]
                self.log_data[log_line["url"]] = {
                    "file_type": log_line["file_type"],
                    "times": 1,
                    "ip_num": 1,
                }

    def report_form_data(self):
        """做一定处理后形成最终的报表数据

        依据{url:{"file_type": str,"times": int,"ip_num": int}}
        生成[URL, 文章标题, 访问人次, 访问IP数]
        :return: 报表数据
        """
        title_getter = TitleGetter()

        for url in self.log_data:
            # 如果是htm/html则获取文章标题
            if self.log_data[url]["file_type"] in ARTICLE_SUFFIX:
                yield [
                    url,
                    title_getter.CAN_NOT_REACH,
                    str(self.log_data[url]["times"]),
                    str(self.log_data[url]["ip_num"]),
                ]
            # 如果不是htm/html则获取文件名
            else:
                # 去掉url后的查询条件，获取真正的路径
                only_route = url.rsplit("?", 1)[0]
                file_name = only_route.rsplit("/", 1)[-1]
                yield [
                    url,
                    # 转为中文
                    urllib_parse.unquote(file_name),
                    str(self.log_data[url]["times"]),
                    str(self.log_data[url]["ip_num"]),
                ]


class IPReportForm(ReportFormBase):
    form_name = "IP报表"
    form_head = ["IP", "访问次数", "访问文章数"]

    def report_form_statistics(self, log_list):
        """解读日志信息

        :param log_list: 日志解读数据，列表，每项有ip、url、file_type三个键
        :return: 无
        """
        # {ip:[]}，将html_url放入列表，从而判断该ip是否被记录过
        ip_and_html_url_cache = {}
        # self.log_data是{ip:{"times": int,"html_url_num": int}}

        for log_line in log_list:
            # 如果ip已被记录，则访问次数+1，并判断访问的html是否有重复
            if log_line["ip"] in ip_and_html_url_cache:
                self.log_data[log_line["ip"]]["times"] += 1
                if log_line["file_type"] in ARTICLE_SUFFIX and \
                   log_line["url"] not in ip_and_html_url_cache[log_line["ip"]]:
                    ip_and_html_url_cache[log_line["ip"]].append(log_line["url"])
                    self.log_data[log_line["ip"]]["html_url_num"] += 1
            # 如果ip未被记录，则创建该记录
            else:
                ip_and_html_url_cache[log_line["ip"]] = [log_line["url"]]
                self.log_data[log_line["ip"]] = {
                    "times": 1,
                    "html_url_num": 1,
                }

    def report_form_data(self):
        """做一定处理后形成最终的报表数据

        依据{ip:{"times": int,"html_url_num": int}}
        生成[IP, 访问次数, 访问文章数]
        :return: 报表数据
        """
        for ip in self.log_data:
            yield [
                ip,
                str(self.log_data[ip]["times"]),
                str(self.log_data[ip]["html_url_num"]),
            ]


class CompleteReportForm(ReportFormBase):
    form_name = "完整报表"
    form_head = ["IP", "URL", "访问次数"]

    def report_form_statistics(self, log_list):
        """解读日志信息

        生成{ip:{url: "times": xxx}}
        :param log_list: 日志解读数据，列表，每项有ip、url、file_type三个键
        :return: 无
        """
        for log_line in log_list:
            # 如果ip已被记录，判断url是否被记录
            if log_line["ip"] in self.log_data:
                if log_line["url"] in self.log_data[log_line["ip"]]:
                    self.log_data[log_line["ip"]][log_line["url"]]["times"] += 1
                # 创建对应的url记录
                else:
                    self.log_data[log_line["ip"]][log_line["url"]] = {"times": 1}
            # 如果ip未被记录，则创建该记录
            else:
                self.log_data[log_line["ip"]] = {
                    log_line["url"]: {"times": 1},
                }

    def report_form_data(self):
        """做一定处理后形成最终的报表数据

        依据{ip:{url: "times": xxx}}
        生成[IP, URL, 访问次数]
        :return: 报表数据
        """
        for ip in self.log_data:
            for url in self.log_data[ip]:
                yield [
                    ip,
                    url,
                    str(self.log_data[ip][url]["times"]),
                ]

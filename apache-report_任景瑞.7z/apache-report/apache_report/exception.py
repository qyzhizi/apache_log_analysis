# coding=utf-8
"""异常类模块"""


class CommonOutputException(Exception):
    def __init__(self, info):
        self.info = info

    def __str__(self):
        return Exception("info")


class FileNotFoundException(Exception):
    def __str__(self):
        return "文件未找到"


class FileStreamException(Exception):
    def __str__(self):
        return "文件流读写异常"


class ValueErrorException(Exception):
    def __str__(self):
        return "数据数值异常"


class TypeErrorException(Exception):
    def __str__(self):
        return "数据类型异常"


class MatchedErrorException(Exception):
    def __str__(self):
        return "数据匹配异常"


class HTTPRequestException(Exception):
    def __str__(self):
        return "HTTP请求异常"

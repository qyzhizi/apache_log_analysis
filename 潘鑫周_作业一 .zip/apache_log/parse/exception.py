# -*- coding: utf-8 -*-
class CheckFileError(Exception):
    """
    检查markdown文件名异常处理
    """

    def __init__(self, filename):
        self.filename = filename

    def __str__(self):
        err_msg = "{} 不是合法的文件名,请检查文件路径是否为.md".format(self.filename)
        return err_msg


class CheckDateError(Exception):
    """
    检查报表数据类型异常处理
    """

    def __init__(self, tablename):
        self.tablename = tablename

    def __str__(self):
        err_msg = "{} 格式错误，请检查数据格式".format(self.tablename)
        return err_msg

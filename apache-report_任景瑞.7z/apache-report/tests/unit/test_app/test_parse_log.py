import unittest
from apache_report.app.parse_log import core_parse_opt


class TestCoreParseOpt(unittest.TestCase):
    def test_illegal_url(self):
        url = '200.200.76.130 - - [16/Feb/2019:11:27:20 +0800] ' \
              '"GET /coding/gitbook/gitbook-plugin-search-plus/' \
              'jquery.mark.min.js HTTP/1.1" 200 13390'
        req = core_parse_opt(url)
        self.assertEqual(
            req.url,
            '/coding/gitbook/gitbook-plugin-search-plus/jquery.mark.min.js')
        self.assertEqual(req.ip, '200.200.76.130')
        self.assertEqual(req.status, '200')
        self.assertEqual(req.method, 'GET')
        self.assertEqual(req.time, '16/Feb/2019:11:27:20 +0800')
        url2 = '::1 - - [16/Feb/2019:11:27:29 +0800] "OPTIONS * HTTP/1.0" ' \
               '200 -'
        req2 = core_parse_opt(url2)
        self.assertEqual(
            req2.url,
            '*')
        self.assertEqual(req2.ip, '::1')
        self.assertEqual(req2.status, '200')
        self.assertEqual(req2.method, 'OPTIONS')
        self.assertEqual(req2.time, '16/Feb/2019:11:27:29 +0800')

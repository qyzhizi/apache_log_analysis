package conf

import (
	yaml "gopkg.in/yaml.v2"
	"io/ioutil"
	"log"
	"os"
	"path"
	"runtime"
	"strings"
)

func getCurrentAbPath() string {
	abPath := ""
	_, file, _, ok := runtime.Caller(0)
	if ok {
		abPath = path.Dir(file)
	} else {
		log.Fatal("conf.yml not exist")
	}
	return abPath
}

/*
	定义读取配置的优先级,读取默认从module/conf下读
	bootstrap.con >> init.conf >> 包内第一个conf
*/
func ReadConf() *LogConf {
	confDir := getCurrentAbPath()
	if !exist(confDir, "") {
		log.Fatal("confDir is not exist")
		return nil
	}
	var confPath string
	if exist(confDir, "bootstrap.yml") {
		confPath = path.Join(confDir, "bootstrap.yml")
	}
	if confPath == "" && exist(confDir, "init.yml") {
		confPath = path.Join(confDir, "init.yml")
	}
	if confPath == "" {
		files, err := ioutil.ReadDir(confDir)
		if err != nil {
			log.Fatal("Read confDir error")
		}
		for _, file := range files {
			if strings.Contains(file.Name(), ".yml") {
				confPath = file.Name()
				break
			}

		}
	}
	// 没有读到配置 报错
	if !strings.Contains(confPath, ".yml") {
		log.Fatal("not read configure")
	}
	conf := doReadConf(confPath)
	return conf
}

func exist(dir string, fileName string) bool {
	filePath := path.Join(dir, fileName)
	_, err := os.Stat(filePath)
	if err == nil {
		return true
	}
	return os.IsExist(err)
}

func doReadConf(confPath string) *LogConf {
	conf := new(LogConf)
	ymlfile, err := ioutil.ReadFile(confPath)
	if err != nil {
		log.Fatal("not read yml File :", confPath)
	}
	err = yaml.Unmarshal(ymlfile, conf)
	if err != nil {
		log.Fatal("yaml analytic is fail")
	}
	return conf
}

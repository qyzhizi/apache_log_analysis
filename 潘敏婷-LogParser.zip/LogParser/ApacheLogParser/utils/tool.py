# -*- coding:utf-8 -*-
import urllib.parse
import requests
from requests import exceptions
import logging
from bs4 import BeautifulSoup
import os

from ApacheLogParser.common import common
from ApacheLogParser.common import exceptions


def unquote_title(title):
    return urllib.parse.unquote(title)


def get_title(url):
    """
    获取页面标题
    :return: 若页面访问失败，则返回None，否则返回获取的标题
    """
    try:
        response = requests.get(url)
    except exceptions.Timeout as e:
        logging.info('请求超时：' + str(e))
        return None
    except exceptions.HTTPError as e:
        logging.info('http请求错误:' + str(e))
        return None
    except Exception as e:
        logging.info("其他未知错误：" + str(e))
        return None
    else:
        # 从返回内容中获取值
        soup = BeautifulSoup(response.text, 'lxml')
        title = 'hhh'
        return title


def get_store_file_abspath(filename):
    """
    根据文件名获得报表的绝对路径, 同一输出到static文件目录下
    :param filename: 报表文件名
    :return:
    """
    root_path = os.path.dirname(os.path.dirname(__file__))
    store_path = os.path.join(root_path, common.DATA_PATH, filename)
    return store_path


def gen_table(report_type, records):
    """
    传入表头和对应的[[]]数据，输出对应的markdown报表
    :param report_type:
    :param records:
    :return:
    """
    rows, cols = len(records), len(records[0])
    report_info = common.REPORT.get(report_type)
    table_header = report_info["header"]
    lines = []

    # 表头部分
    lines += [common.PLACEHOLDER_3.format(common.PLACEHOLDER_2.join(table_header))]

    # 分割线
    tmp = common.PLACEHOLDER_2
    for i in range(cols):
        line = common.PLACEHOLDER_1 .format(common.PLACEHOLDER_DATA .format(common.SEP_4 * len(table_header[i])))
        tmp = ''.join([tmp, line])
    lines += [tmp]

    # 数据部分
    for record in records:
        d = list(map(str, record))
        lines += [common.PLACEHOLDER_3.format(common.PLACEHOLDER_4.join(d))]

    table_data = common.NEW_LINE_CHAR.join(lines)
    save_table(report_info["file_name"], table_data)


def save_table(file_name, data):
    """
    将处理好的数据转换为表格的形式，并保存到文件
    :param file_name: 文件名
    :param data: 报表中填充的数据 [[],[]]
    :return: 生成的报表文件
    """
    file_path = get_store_file_abspath(file_name)
    with open(file_path, 'w') as f:
        f.write(data)


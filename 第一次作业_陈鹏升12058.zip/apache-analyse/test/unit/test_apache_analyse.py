# -*- coding: utf-8 -*-

import unittest

import mock

from apache_analyse.common.constant import COMMON_MOCK_PATH
from apache_analyse.common.constant import DEFAULT_APACHE_LOG_PATH
from apache_analyse.app.analyse.provider import ApacheAnalyse


class TestApacheAnalyse(unittest.TestCase):
    u"""apache日志分析测试类."""

    mock_apache_list = ['63.55.33.184 - - [16/Feb/2019:11:27:20 +0800] '
                        '"HEAD /coding/miniprj/2302b33f1f9546098a85c4709f27fa7'
                        '0.css HTTP/1.1" 200 38093',
                        '139.54.176.240 - - [16/Feb/2019:11:27:20 +0800] '
                        '"DELETE /coding/miniprj/0e5e3d67442143e4'
                        '9367a24b2a40f658.html HTTP/1.1" 200 38093']

    mock_filter_log_list = [{'ip': '139.54.176.240', 'method': '"DELETE',
                             'url': '/coding/miniprj/0e5e3d67442143e49367a24'
                                    'b2a40f658.html', 'type': 'html',
                             'title': '0e5e3d67442143e49367a24b2a40f658',
                             'status_code': '200'}]

    def setUp(self):
        pass

    def tearDown(self):
        pass

    @mock.patch("%s.common.common.filter_log" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.save" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.load" % COMMON_MOCK_PATH)
    def test_get_article_report(self, mock_load, mock_save, mock_filter_log):
        # 构造数据
        mock_load.return_value = self.mock_apache_list
        mock_filter_log.return_value = self.mock_filter_log_list

        # 调用
        apache_analyse = ApacheAnalyse()
        article_table_dict = apache_analyse.get_article_report()

        # 模拟返回的数据
        mock_article_table_dict = {'/coding/miniprj/0e5e3d67442143e49367a24b2'
                                   'a40f658.html':
                                       {'url': '/coding/miniprj/0e5e3d6744214'
                                               '3e49367a24b2a40f658.html',
                                        'title': '0e5e3d67442143e49367a24b2a4'
                                                 '0f658', 'url_type': 'html',
                                        'visits': 1, 'ip_counts': 1,
                                        'ip_dist': {'139.54.176.240':
                                                    '139.54.176.240'}}}

        # 断言
        mock_load.assert_any_call(DEFAULT_APACHE_LOG_PATH)
        self.assertEqual(len(article_table_dict), len(mock_article_table_dict))
        self.assertEqual(article_table_dict.keys(),
                         mock_article_table_dict.keys())
        for article_table, mock_article_table in \
                zip(article_table_dict.values(),
                    mock_article_table_dict.values()):
            self.assertDictEqual(article_table,
                                 mock_article_table)

    @mock.patch("%s.common.common.filter_log" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.save" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.load" % COMMON_MOCK_PATH)
    def test_get_ip_report(self, mock_load, mock_save, mock_filter_log):
        # 构造数据
        mock_load.return_value = self.mock_apache_list
        mock_filter_log.return_value = self.mock_filter_log_list

        # 调用
        apache_analyse = ApacheAnalyse()
        ip_table_dict = apache_analyse.get_ip_report()

        # 模拟返回的数据
        mock_ip_table_dict = {'139.54.176.240': {'ip': '139.54.176.240',
                                                 'visits': 1,
                                                 'visits_article': 1,
                                                 'url_dist':
                                                     {'/coding/miniprj/0e5e3d'
                                                      '67442143e49367a24b2a40'
                                                      'f658.html':
                                                          '/coding/miniprj/0e'
                                                          '5e3d67442143e49367a'
                                                          '24b2a40f658.html'}}}

        # 断言
        self.assertEqual(len(ip_table_dict), len(mock_ip_table_dict))
        self.assertEqual(ip_table_dict.keys(), mock_ip_table_dict.keys())
        for ip_table, mock_ip_table in zip(ip_table_dict.values(),
                                           mock_ip_table_dict.values()):
            self.assertEqual(ip_table['ip'], mock_ip_table['ip'])
            self.assertEqual(ip_table['visits'], mock_ip_table['visits'])
            self.assertEqual(ip_table['visits_article'],
                             mock_ip_table['visits_article'])
            self.assertDictEqual(ip_table['url_dist'],
                                 mock_ip_table['url_dist'])

    @mock.patch("%s.common.common.filter_log" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.save" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.load" % COMMON_MOCK_PATH)
    def test_get_complete_report(self, mock_load, mock_save, mock_filter_log):
        # 构造数据
        mock_load.return_value = self.mock_apache_list
        mock_filter_log.return_value = self.mock_filter_log_list

        # 调用
        apache_analyse = ApacheAnalyse()
        complete_table_dict = apache_analyse.get_complete_report()

        # 模拟返回的数据
        mock_complete_table_dict = {'139.54.176.240-/coding/miniprj/0e5e3d6744'
                                    '2143e49367a24b2a40f658.html':
                                        {'ip': '139.54.176.240',
                                         'url': '/coding/miniprj/0e5e3d6744214'
                                                '3e49367a24b2a40f658.html',
                                         'visits': 1}}

        # 断言
        self.assertEqual(len(complete_table_dict),
                         len(mock_complete_table_dict))
        self.assertEqual(complete_table_dict.keys(),
                         mock_complete_table_dict.keys())
        for complete_table, mock_complete_table in \
                zip(complete_table_dict.values(),
                    mock_complete_table_dict.values()):
            self.assertDictEqual(complete_table,
                                 mock_complete_table)

    @mock.patch("%s.common.common.filter_log" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.save" % COMMON_MOCK_PATH)
    @mock.patch("%s.app.analyse.provider.DataManager.load" % COMMON_MOCK_PATH)
    def test_get_report_by_pool(self, mock_load, mock_save, mock_filter_log):
        mock_load.return_value = self.mock_apache_list * 1000000
        mock_filter_log.return_value = self.mock_filter_log_list * 1000000
        mock_complete_table_dict = {'139.54.176.240-/coding/miniprj/0e5e3d6'
                                    '7442143e49367a24b2a40f658.html':
                                        {'ip': '139.54.176.240',
                                         'url': '/coding/miniprj/0e5e3d6744214'
                                                '3e49367a24b2a40f658.html',
                                         'visits': 900000}}

        # 调用
        apache_analyse = ApacheAnalyse()
        complete_table_dict = apache_analyse.get_complete_report()

        # 断言
        self.assertEqual(len(complete_table_dict),
                         len(mock_complete_table_dict))
        self.assertEqual(complete_table_dict.keys(),
                         mock_complete_table_dict.keys())
        for complete_table, mock_complete_table in \
                zip(complete_table_dict.values(),
                    mock_complete_table_dict.values()):
            self.assertDictEqual(complete_table,
                                 mock_complete_table)


if __name__ == '__main__':
    unittest.main()

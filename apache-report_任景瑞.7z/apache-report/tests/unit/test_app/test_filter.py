import unittest

from apache_report.app.filter import Filter
from apache_report.app.request import RequestStore


class TestFilter(unittest.TestCase):
    def setUp(self):
        self.req1 = RequestStore('200.200.76.130',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '/designing/tools/image/favicon.ico')
        self.req2 = RequestStore('200.200.76.130',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '/designing/tools/imacs/abcn.css')
        self.req3 = RequestStore('200.200.76.130',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '/designing/tools/faas.js')
        self.req4 = RequestStore('200.200.76.130',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '/designing/tools/bca.htm')
        self.req5 = RequestStore('200.200.76.130',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '')
        self.req6 = RequestStore('',
                                 '16/Feb/2019:11:27:21',
                                 'GET',
                                 '')
        self.req_list = [self.req1, self.req2, self.req3, self.req4, self.req5,
                         self.req6]
        self.ft = Filter(['js', 'css'])

    def test_filter_target_page(self):
        url = '/designing/tools/bca.htm'
        url2 = '/designing/tools/imacs/abcn.css'
        self.assertTrue(self.ft.filter_target_page(url))
        self.assertFalse(self.ft.filter_target_page(url2))

    def test_filter_valid_req(self):
        self.assertTrue(self.ft.filter_valid_req(self.req1))
        self.assertTrue(self.ft.filter_valid_req(self.req4))
        self.assertFalse(self.ft.filter_valid_req(self.req2))
        self.assertFalse(self.ft.filter_valid_req(self.req3))
        self.assertFalse(self.ft.filter_valid_req(self.req5))
        self.assertFalse(self.ft.filter_valid_req(self.req6))


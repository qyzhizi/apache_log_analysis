# -*- coding: utf-8 -*-
import os
import requests
import re
from apache_log.common.const import FILE_FILTER


def get_log_files(path):
    """
    获取指定文件夹下的log日志路径
    :param path: 日志文件夹路径
    :return: list 文件列表
    """
    files = []
    for file in os.listdir(path):
        file = os.path.join(path, file)
        if os.path.splitext(file)[1] == '.log':
            files.append(file)
    return files


def get_topic_name(url, endpoint):
    u"""
    通过url获取文章的title
    :param: url: url路径
    :return: topic_name: 文章名称
    """
    if url.endswith(('.html', '.htm')):
        topic_name = get_html_title(url, endpoint)
    else:
        r = url.rindex('/')
        topic_name = url[r + 1:]
    return topic_name


def get_html_title(url, endpoint):
    """
    获取html页面的title标签
    :param url: url路径
    :return: html_title: html页面的title标签
    """
    html = requests.get(endpoint + url).text
    pattern = '<title>(.+?)</title>'
    html_title = re.findall(pattern, html)[0][2:-1]
    return html_title


def read_file(filename):
    """
    :param filename: 文件路径
    :return: 文件数据
    """
    with open(filename) as f:
        data = f.read()
    return data


def check_file(filename):
    """
    :param filename: 文件名称
    :return: bool 检查结果
    """
    # 检查文件路径是否为.md结尾
    if filename[-3:] != '.md':
        return False
    else:
        return True


def parse_file(conn, file_data):
    """
    :param file_data: 管道
    :param file_data: 文件数据
    :return:  handle_data 解析文件数据，构造完整表格数据
    {
       ('127.0.0.1', '/coding/gitbook/gitbook-plugin-anchors/plugin.html') : 77
        ...
    }
    """
    handle_data = {}
    for line in file_data.split('\n'):
        ip, url = parse_line(line)
        if not (ip and url):
            continue
        # 需要过滤掉css,js,zip等文件的访问
        if url.endswith(FILE_FILTER):
            continue
        key = (ip, url)
        if key in handle_data:
            handle_data[key] += 1
        else:
            handle_data[key] = 1
    conn.send(handle_data)
    conn.close()


def parse_line(log_line):
    u"""
    解析文件函数获取 ip 和 url
    注: 由于apache的日志可以根据需求调整和改变，不可以使用spilt的方式,需要采用re的方式
    :param log_line: 日志文件的行信息
    :return: ip信息 以及 url信息
    """
    ip, url = '', ''
    ip_pattern = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
    url_pattern = r'\s(/[\S]+)+\s'
    ip_match = re.findall(ip_pattern, log_line)
    url_match = re.findall(url_pattern, log_line)
    if ip_match:
        ip = ip_match[0]
    if url_match:
        url = url_match[0]
        # url需要过滤掉parma参数
        index = url.rfind("?")
        if index != -1:
            url = url[:index]
    return ip, url


def sum_dict(dictA, dictB):
    """
    两个字典相加处理
    :param dictA: 字典A
    :param dictB: 字典B
    :return:
    """
    for key, value in dictB.items():
        if key in dictA:
            dictA[key] += value
        else:
            dictA[key] = value
    return dictA

package report

import "io"

type Report interface {
	Init()
	SetTitle([]string)
	GetTitle() []string
	Set(key string, value string)
	Export(writer io.Writer, exportType string)
	Names() string
	Merge(report Report)
	Finish()
	Values() interface{}
}
//type ReportContent interface{}

func GetReport(rep string) Report {
	var report Report
	if rep == "ip" {
		report = &IPReport{Report: make(map[string]*IPReportContent)}
	} else if rep == "article" {
		report = &ArticleReport{Report: make(map[string]*ArticleReportContent)}
	} else if rep == "all" {
		report = &AllReport{ReportConetent: make(map[string]int)}
	}
	_, ok := report.(Report)
	if !ok {
		report.Init()
	}
	return report
}

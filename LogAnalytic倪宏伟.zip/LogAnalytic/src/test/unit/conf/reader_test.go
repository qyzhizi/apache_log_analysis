package test

import (
	"nhw-log/conf"
	"testing"
)

func TestLogRead(t *testing.T) {
	readConf := conf.ReadConf()
	reader := conf.LogRead(readConf)
	if reader == nil{
		t.Fatalf("read log error")
	}
}
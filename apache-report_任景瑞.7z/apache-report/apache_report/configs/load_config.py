# coding=utf-8
import logging
import os

import configparser

from apache_report import exception
from apache_report.common.utils import set_logger

logger = set_logger(level=logging.ERROR)


def set_config(file_name='config.ini'):
    path = os.path.abspath(os.path.dirname(__file__))
    cfg = configparser.ConfigParser()
    cfg.read(os.path.join(path, file_name), encoding='utf-8')
    # logger.debug('读取配置文件为%s' % os.path.join(path, file_name))
    sect = cfg.sections()
    if not sect:
        raise exception.FileNotFoundException()
    # Load file settings by attributes
    # logger.debug("Load config: {}".format(sect))
    return cfg


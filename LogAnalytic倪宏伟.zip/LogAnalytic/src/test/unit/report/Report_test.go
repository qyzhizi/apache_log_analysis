package test

import (
	"nhw-log/report"
	"testing"
)

func TestReportInit(t *testing.T) {
	rept := &report.IPReport{}
	rept.Init()
	if rept.Name != "ip" {
		t.Fatalf("report init error")
	}

}

func TestReportSet(t *testing.T) {
	rept := &report.IPReport{}
	rept.Init()
	rept.Set("/hhhh.html", "200.200.0.1")
	if len(rept.Report) != 1 {
		t.Fatalf("set item error")
	}
}

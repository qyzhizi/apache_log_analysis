# coding=utf-8
"""规范化存储数据"""
from apache_report import exception
from apache_report.common.utils import set_logger

logger = set_logger()


def format_check(data, cols_name, rows_name):
    """检查保存的数据格式是否正常"""
    if not cols_name:
        logger.exception('列名不能为空')
        return False
    if not data:
        logger.exception('数据不能为空')
        return False
    try:
        h = len(data)
        w = len(data[0])
    except KeyError:
        logger.error('数据存在错误')
        return False
    if w != len(cols_name):
        logger.exception('列名数与数据列数不符')
        return False
    if rows_name is not None and h != len(rows_name):
        logger.exception('行名数与数据行数不符')
        return False
    return True


def markdown_format(data, cols_name, rows_name=None, head_name=None):
    """生成markdown格式数据报表"""
    if not format_check(data, cols_name, rows_name):
        raise exception.ValueErrorException

    height, weight = len(data), len(data[0])
    if head_name is None:
        return markdown_format_without_head(data, cols_name)
    if rows_name is None:
        rows_name = ['' for _ in range(height)]
    lines = ['| {} | {} |'.format(head_name, ' | '.join(cols_name))]

    # 生成分割线
    spl_format = '{}:'
    line = '| {} |'.format(spl_format.format('-' * len(head_name)))
    for i in range(weight):
        line = '{} {} |'.format(
            line, spl_format.format('-' * len(cols_name[i])))
    lines.extend([line])
    # 填入数据
    for i in range(height):
        d = list(map(str, list(data[i])))
        lines.extend(['| {} | {} |'.format(rows_name[i], ' | '.join(d))])
    table = '\n'.join(lines)
    return table


def markdown_format_without_head(data, cols_name):
    """不使用表头行名生成数据报表"""
    lines = ['| {} |'.format(' | '.join(cols_name))]
    height, weight = len(data), len(data[0])
    # 生成分割线
    spl_format = '{}:'
    line = '|'
    for i in range(weight):
        line = '{} {} |'.format(
            line, spl_format.format('-' * len(cols_name[i])))
    lines.extend([line])
    # 填入数据
    for i in range(height):
        d = list(map(str, list(data[i])))
        lines.extend(['| {} |'.format(' | '.join(d))])
    table = '\n'.join(lines)
    return table


# Other format



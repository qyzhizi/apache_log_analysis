from unittest import TestCase
from helper import get_page_title
from helper import get_ip_add_and_url


class TestHelper(TestCase):

    def test_get_page_title(self):
        url = 'https://www.runoob.com/'
        title = get_page_title(url)
        self.assertEqual(title, '菜鸟教程 - 学的不仅是技术，更是梦想！')

    def test_get_ip_add_and_url(self):
        file_filter = ['htm', 'html', 'pdf', 'doc', 'zip', 'docx', 'mpg']
        # 正常GET请求
        normal_log = '177.1.81.42 - - [16/Feb/2019:11:28:54 +0800] "GET /designing/tools/image/UML_classes.docx HTTP/1.1" 200 156676'
        ip_add, file_url = get_ip_add_and_url(normal_log, file_filter)
        self.assertEqual(ip_add, '177.1.81.42')
        self.assertEqual(file_url, '/designing/tools/image/UML_classes.docx')
        # 非GET请求
        wrong_log = '::1 - - [16/Feb/2019:11:27:29 +0800] "OPTIONS * HTTP/1.0" 200 -'
        res = get_ip_add_and_url(wrong_log, file_filter)
        self.assertEqual(res, None)
        # 其他文件格式的
        other_log = '200.200.76.130 - - [16/Feb/2019:11:27:20 +0800] "GET /coding/gitbook/gitbook-plugin-ace/ace/ace.js HTTP/1.1" 200 347010'
        res = get_ip_add_and_url(other_log, file_filter)
        self.assertEqual(res, None)


import unittest

from apache_report import exception
from apache_report.storing.formatting import format_check
from apache_report.storing.formatting import markdown_format
from apache_report.storing.formatting import markdown_format_without_head


class TestFormatCheck(unittest.TestCase):
    def setUp(self):
        super(TestFormatCheck, self).setUp()
        self.data1 = [[1, 2], [3, 4], [5, 6]]
        self.data2 = [['1', '2', '3'], ['4', '5', '6']]
        self.cols1 = ['col1', 'col2']
        self.cols2 = ['col1', 'col2', 'col3']
        self.rows1 = ['row1', 'row2', 'row3']
        self.rows2 = ['row1', 'row2']

    def test_none_data(self):
        self.assertFalse(format_check(None, 'cols_name', 'rows_name'))
        self.assertFalse(format_check('data', None, 'rows_name'))

    def test_unmatched_data(self):
        self.assertFalse(format_check(self.data2, self.cols1, self.rows1))
        self.assertFalse(format_check(self.data2, self.cols2, self.rows1))

    def test_wrong_data(self):
        self.assertFalse(format_check({1: '1'}, 'cols', 'rows_name'))

    def test_right_format(self):
        self.assertTrue(format_check(self.data1, self.cols1, self.rows1))
        self.assertTrue(format_check(self.data2, self.cols2, self.rows2))


class TestMarkdown(unittest.TestCase):
    def setUp(self):
        super(TestMarkdown, self).setUp()
        self.data1 = [[1, 2], [3, 4], [5, 6]]
        self.data2 = [['1', '2', '3'], ['4', '5', '6']]
        self.cols1 = ['col1', 'col2']
        self.cols2 = ['col1', 'col2', 'col3']
        self.rows1 = ['row1', 'row2', 'row3']
        self.rows2 = ['row1', 'row2']
        self.head1 = 'Test1'
        self.actual1 = ['| col1 | col2 |', '| ----: | ----: |',
                        '| 1 | 2 |', '| 3 | 4 |', '| 5 | 6 |']
        self.actual2 = ['| col1 | col2 | col3 |', '| ----: | ----: | ----: |',
                        '| 1 | 2 | 3 |', '| 4 | 5 | 6 |']

    def test_illegal_data(self):
        self.assertRaises(exception.ValueErrorException,
                          markdown_format,
                          self.data2, self.cols2, self.rows1)
        self.assertRaises(exception.ValueErrorException,
                          markdown_format,
                          {1: '1'}, 'cols', 'rows_name')
        self.assertRaises(exception.ValueErrorException,
                          markdown_format,
                          'data', None, 'rows_name')

    def test_markdown_without_head(self):
        self.assertEqual(markdown_format_without_head(self.data1, self.cols1),
                         '\n'.join(self.actual1))
        self.assertEqual(markdown_format_without_head(self.data2, self.cols2),
                         '\n'.join(self.actual2))

    def test_markdown(self):
        res = markdown_format(self.data1, self.cols1, self.rows1)
        res2 = markdown_format(self.data2, self.cols2)
        self.assertEqual(res, '\n'.join(self.actual1))
        self.assertEqual(res2, '\n'.join(self.actual2))

        res3 = markdown_format(self.data1, self.cols1, self.rows1, self.head1)
        res4 = markdown_format(self.data2, self.cols2, self.rows2, self.head1)
        actual3 = ['| Test1 | col1 | col2 |', '| -----: | ----: | ----: |',
                   '| row1 | 1 | 2 |', '| row2 | 3 | 4 |', '| row3 | 5 | 6 |'
                   ]
        actual4 = ['| Test1 | col1 | col2 | col3 |',
                   '| -----: | ----: | ----: | ----: |',
                   '| row1 | 1 | 2 | 3 |', '| row2 | 4 | 5 | 6 |'
                   ]

        self.assertEqual(res3, '\n'.join(actual3))
        self.assertEqual(res4, '\n'.join(actual4))


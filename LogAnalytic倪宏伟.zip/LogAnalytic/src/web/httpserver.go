package web

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"nhw-log/report"
	web "nhw-log/web/router"
)

func RunWebServer(httpAddress string, reportMap map[string]report.Report) {
	NewtHttpServer(httpAddress, reportMap)
}

func NewtHttpServer(httpAddress string, reportMap map[string]report.Report) {
	mux := http.NewServeMux()
	web.Router(mux, reportMap)
	listen, err := net.Listen("tcp", httpAddress)
	if err != nil {
		fmt.Println("listen port failed")
	}
	err = http.Serve(listen, mux)
	if err != nil {
		log.Fatal("web start error")
	}
}

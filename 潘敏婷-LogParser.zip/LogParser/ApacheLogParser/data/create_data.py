# -*- coding:utf-8 -*-
import faker
import random
from datetime import datetime
import time

from ApacheLogParser.common.common import (
    SEP_4,
    SEP_5,
    REQUEST_PROTOCOL
)
from ApacheLogParser.utils.tool import get_store_file_abspath
from ApacheLogParser.common.common import APACHE_LOG_FILE

DATE_FORMAT = '[%d/%b/%Y:%H:%M:%S +0800]'


class LogMock(object):

    def __init__(self):
        self.faker = faker.Faker(locale='zh-CN')
        self.method_code_mapping = {
            1: {"method": "GET", "code": 200},
            2: {"method": "POST", "code": 404},
            3: {"method": "PUT", "code": 303},
            4: {"method": "DELETE", "code": 302}
        }
        self.mock_ips = self.gen_ips()
        self.mock_urls = self.gen_urls()

    def gen_ips(self):
        mock_ips = []
        for i in range(0, 100):
            mock_ips.append(self.faker.ipv4())
        return mock_ips

    def get_random_url(self):
        index = random.randint(1, 99)
        return self.mock_urls[index]

    def gen_urls(self):
        mock_urls = []
        for i in range(0, 100):
            mock_urls.append(self.faker.image_url() + self.faker.uri_extension())
        return mock_urls

    def get_random_ip(self):
        index = random.randint(1, 99)
        return self.mock_ips[index]

    @staticmethod
    def gen_random_date():
        return datetime.utcnow().strftime(DATE_FORMAT)

    def gen_random_method(self):
        num = self.gen_random_num(1, 4)
        tmp = self.method_code_mapping.get(num)
        return tmp["method"], tmp["code"]

    @staticmethod
    def gen_random_num(start=1, end=10000):
        return random.randint(start, end)

    def gen_log_record(self):
        ip = self.get_random_ip()
        method, code = self.gen_random_method()
        url = " ".join([SEP_5 + method, self.get_random_url(), REQUEST_PROTOCOL + SEP_5])
        duration = self.gen_random_num(200, 20000)
        random_date = self.gen_random_date()
        record = " ".join([ip, SEP_4, SEP_4, str(random_date), url, str(code), str(duration)])
        return record

    def mock_records(self, times=5000000):
        records = []
        for i in range(times):
            records.append(self.gen_log_record())
        return records

    @staticmethod
    def save_mock_log(records):
        try:
            with open(get_store_file_abspath(APACHE_LOG_FILE), "w") as f:
                f.write('\n'.join(records))
        except IOError:
            raise IOError()


start = time.time()
t = LogMock()
records = t.mock_records()
t.save_mock_log(records)
print(time.time() - start)

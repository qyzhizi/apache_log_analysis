import time
import yaml

from reporter import PageReporter
from reporter import IPReporter
from reporter import FullReporter
from analyzer import Analyzer, Runner
from gen_test_data import gen_fake_apache_log


if __name__ == '__main__':
    # 设置进程数
    import sys
    workers = 16
    if sys.argv[1]:
        workers = int(sys.argv[1])
    # 加载配置文件
    config_file = open('config.yaml', 'r', encoding='utf-8')
    configs = yaml.safe_load(config_file.read())

    # 生成测试数据
    ip_start_add = configs['ip_start_add']
    ip_num = configs['ip_num']
    log_num = configs['log_num']
    output_file_path = configs['output_file_path']

    start_time = time.time()
    gen_fake_apache_log(ip_start_add, ip_num, log_num, output_file_path)
    print("生成{}条测试数据，耗时{}s。".format(log_num, time.time() - start_time))

    # 日志分析
    input_file_path = configs['input_file_path']
    # 保留的文件类型
    file_filter = configs['file_filter']
    # 报表输出路径
    page_report_path = configs['page_report_path']
    ip_report_path = configs['ip_report_path']
    full_report_path = configs['full_report_path']
    # 运行
    start_time = time.time()
    runner = Runner(
        input_file_path,
        file_filter,
        workers,
        page_report_path,
        ip_report_path,
        full_report_path
    )
    runner.run()
    end_time = time.time()
    print("日志解析完成，总耗时：{}".format(end_time - start_time))

    # analyzer.gen_reports()
    # print("报表生成完成。")
